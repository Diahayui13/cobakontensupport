<?php

namespace Database\Seeders;

use App\Models\ActivityLog;
use App\Models\AiRequest;
use App\Models\Article;
use App\Models\Caption;
use App\Models\ContentType;
use App\Models\Platform;
use App\Models\User;
use Illuminate\Database\Seeder;

class ArticleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::first();
        if (!$user) {
            return;
        }

        $contentType = ContentType::where('name', 'Berita Lugas')->first();

        $article = Article::updateOrCreate(
            ['title' => 'Jembatan Baru Rajekwesi Diresmikan, Urai Kemacetan Akses Selatan Bojonegoro'],
            [
                'user_id' => $user->id,
                'body' => 'BOJONEGORO, RADAR BOJONEGORO - Arus lalu lintas di jalur selatan Bojonegoro kini dipastikan lebih lancar setelah Jembatan Baru Rajekwesi resmi diresmikan oleh Pemerintah Kabupaten Bojonegoro pada Minggu (11/10/2026). Jembatan dengan bentang panjang 45 meter ini dibangun untuk menggantikan struktur jembatan lama yang kerap menjadi titik penumpukan kendaraan pada jam sibuk kerja dan libur akhir pekan.\n\nBupati Bojonegoro dalam sambutannya menegaskan pembangunan jembatan ini rampung dua pekan lebih cepat dari target semula. "Jembatan ini adalah urat nadi perekonomian warga yang menghubungkan sentra pertanian dan perdagangan kota," ujarnya. Warga sekitar menyambut antusias pengoperasian infrastruktur baru tersebut.',
                'notes_for_ai' => 'Tekankan kutipan bupati dan selesainya 2 pekan lebih cepat.',
                'content_type' => '1',
                'content_type_id' => $contentType?->id,
            ]
        );

        $platformInstagram = Platform::where('slug', 'instagram')->first();
        $platformFacebook = Platform::where('slug', 'facebook')->first();
        $platformX = Platform::where('slug', 'x')->first();
        $platformTiktok = Platform::where('slug', 'tiktok')->first();
        $platformYoutube = Platform::where('slug', 'youtube')->first();

        if ($platformInstagram) {
            Caption::updateOrCreate(
                ['article_id' => $article->id, 'platform_id' => $platformInstagram->id, 'attempt_no' => 1],
                [
                    'ai_text' => 'Kabar gembira bagi masyarakat Bojonegoro. Jembatan Baru Rajekwesi resmi diresmikan Pemkab Bojonegoro pada Minggu (11/10/2026) untuk mengurai kepadatan di akses selatan. Proyek ini selesai 2 pekan lebih cepat dari target. #RadarBojonegoro #Bojonegoro',
                    'final_text' => "Kabar gembira buat warga Bojonegoro! 🎉 Jembatan Baru Rajekwesi resmi diresmikan hari ini, Minggu (11/10). Dengan bentang 45 meter, jembatan ini siap urai kemacetan akses jalur selatan yang menghubungkan sentra ekonomi dan pertanian warga.\n\nPembangunannya bahkan tuntas 2 pekan lebih cepat dari target awal lho! Siapa nih yang tadi sudah sempat melintas? Tulis komentarmu di bawah ya! 👇\n\n#RadarBojonegoro #Rajekwesi #BojonegoroHariIni #InfrastrukturBojonegoro #KabarBojonegoro",
                    'hashtags' => ['#RadarBojonegoro', '#Rajekwesi', '#BojonegoroHariIni', '#InfrastrukturBojonegoro', '#KabarBojonegoro'],
                    'summary' => 'Jembatan Baru Rajekwesi selesai 2 pekan lebih cepat untuk urai kemacetan.',
                    'status' => 'siap',
                    'ready_at' => now(),
                ]
            );
        }

        if ($platformFacebook) {
            Caption::updateOrCreate(
                ['article_id' => $article->id, 'platform_id' => $platformFacebook->id, 'attempt_no' => 1],
                [
                    'ai_text' => 'Pemerintah Kabupaten Bojonegoro meresmikan Jembatan Baru Rajekwesi pada Minggu (11/10/2026). Jembatan ini memiliki bentang 45 meter dan selesai 2 pekan lebih cepat dari rencana untuk menghubungkan sentra pertanian dan perdagangan warga.',
                    'final_text' => "URAI KEMACETAN JALUR SELATAN, JEMBATAN BARU RAJEKWESI RESMI DIRESMIKAN\n\nBojonegoro - Arus lalu lintas di jalur selatan Bojonegoro kini dipastikan lebih lancar setelah Jembatan Baru Rajekwesi resmi diresmikan oleh Pemkab Bojonegoro pada Minggu (11/10/2026).\n\nJembatan dengan bentang sepanjang 45 meter ini dibangun untuk menggantikan struktur jembatan lama yang kerap menjadi titik penumpukan kendaraan. Menariknya, pengerjaan jembatan ini berhasil selesai dua pekan lebih cepat dari jadwal semula.\n\nSimak ulasan selengkapnya di portal radarbojonegoro.jawapos.com\n\n#RadarBojonegoro #BeritaBojonegoro #InfrastrukturJawaTimur",
                    'hashtags' => ['#RadarBojonegoro', '#BeritaBojonegoro', '#InfrastrukturJawaTimur'],
                    'summary' => 'Peresmian Jembatan Baru Rajekwesi Bojonegoro.',
                    'status' => 'siap',
                    'ready_at' => now(),
                ]
            );
        }

        if ($platformX) {
            Caption::updateOrCreate(
                ['article_id' => $article->id, 'platform_id' => $platformX->id, 'attempt_no' => 1],
                [
                    'ai_text' => 'Jembatan Baru Rajekwesi Bojonegoro diresmikan hari ini! Bentang 45 meter tuntas 2 pekan lebih cepat untuk urai kemacetan jalur selatan. #Bojonegoro',
                    'final_text' => 'Jembatan Baru Rajekwesi resmi dibuka hari ini (11/10)! Selesai 2 pekan lebih cepat dari target, siap urai macet jalur selatan Bojonegoro. Sudah coba lewat sini lur? #RadarBojonegoro #Bojonegoro',
                    'hashtags' => ['#RadarBojonegoro', '#Bojonegoro'],
                    'summary' => 'Jembatan Rajekwesi resmi dibuka.',
                    'status' => 'siap',
                    'ready_at' => now(),
                ]
            );
        }

        if ($platformTiktok) {
            Caption::updateOrCreate(
                ['article_id' => $article->id, 'platform_id' => $platformTiktok->id, 'attempt_no' => 1],
                [
                    'ai_text' => 'Jembatan Baru Rajekwesi Bojonegoro sudah diresmikan dan bisa dilewati! Urai macet jalur selatan. #Bojonegoro #RadarBojonegoro',
                    'final_text' => 'Jembatan Rajekwesi Bojonegoro resmi diresmikan lur! 🎉 Jalur selatan gak macet lagi nih. Selesainya malah 2 minggu lebih cepat. Ada yang udah lewat? #Bojonegoro #RadarBojonegoro #fyp',
                    'hashtags' => ['#Bojonegoro', '#RadarBojonegoro', '#fyp'],
                    'summary' => 'Jembatan Rajekwesi resmi dibuka 2 minggu lebih cepat.',
                    'status' => 'draf',
                ]
            );
        }

        if ($platformYoutube) {
            Caption::updateOrCreate(
                ['article_id' => $article->id, 'platform_id' => $platformYoutube->id, 'attempt_no' => 1],
                [
                    'ai_text' => 'Pemerintah Kabupaten Bojonegoro resmi mengoperasikan Jembatan Baru Rajekwesi pada Minggu (11/10/2026). Jembatan sepanjang 45 meter ini selesai dua pekan lebih cepat dan siap mengurai kepadatan jalur selatan. Bupati menegaskan jembatan ini menjadi urat nadi perputaran ekonomi pertanian dan perdagangan. Baca berita selengkapnya di radarbojonegoro.jawapos.com. #RadarBojonegoro #Bojonegoro',
                    'final_text' => "Jembatan Baru Rajekwesi resmi diresmikan oleh Pemerintah Kabupaten Bojonegoro pada Minggu (11/10/2026). Infrastruktur dengan bentang 45 meter ini rampung dua pekan lebih cepat dari target untuk mengurai kemacetan akses jalur selatan yang kerap memadat saat jam sibuk.\n\nDalam peresmian tersebut, Bupati Bojonegoro menegaskan bahwa jembatan ini menjadi urat nadi perekonomian warga yang menghubungkan kawasan sentra pertanian dan perdagangan kota. Akses baru ini kini sudah dapat dilintasi oleh seluruh jenis kendaraan bermotor.\n\nSimak berita selengkapnya di portal resmi radarbojonegoro.jawapos.com atau baca edisi cetak Harian Pagi Radar Bojonegoro.\n\n#RadarBojonegoro #Rajekwesi #Bojonegoro #BeritaBojonegoro #InfrastrukturBojonegoro",
                    'hashtags' => ['#RadarBojonegoro', '#Rajekwesi', '#Bojonegoro'],
                    'summary' => 'Peresmian Jembatan Baru Rajekwesi di jalur selatan Bojonegoro.',
                    'status' => 'draf',
                ]
            );
        }

        AiRequest::create([
            'article_id' => $article->id,
            'started_at' => now()->subSeconds(3),
            'duration_ms' => 1350,
            'status' => 'success',
        ]);

        ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'article_created',
            'object_type' => 'Article',
            'object_id' => $article->id,
            'created_at' => now(),
        ]);
    }
}

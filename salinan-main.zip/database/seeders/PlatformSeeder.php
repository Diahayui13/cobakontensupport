<?php

namespace Database\Seeders;

use App\Models\Platform;
use Illuminate\Database\Seeder;

class PlatformSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $platforms = [
            [
                'name' => 'Instagram',
                'slug' => 'instagram',
                'char_limit' => 2200, // TODO-VERIFY
                'image_ratios' => ['1:1', '4:5', '9:16'],
                'style_rules' => 'Gaya bahasa ramah dan menarik pembaca, interaktif dengan pertanyaan di akhir, dan hashtag relevan.',
            ],
            [
                'name' => 'Facebook',
                'slug' => 'facebook',
                'char_limit' => 63206, // TODO-VERIFY
                'image_ratios' => ['1:1', '16:9', '4:5'],
                'style_rules' => 'Gaya bahasa informatif dan runtut, mencantumkan pokok fakta berita secara jelas.',
            ],
            [
                'name' => 'X',
                'slug' => 'x',
                'char_limit' => 280, // TODO-VERIFY
                'image_ratios' => ['16:9', '1:1'],
                'style_rules' => 'Ringkas, padat, langsung ke inti berita (hard facts), tidak melebihi batas ketat 280 karakter.',
            ],
            [
                'name' => 'TikTok',
                'slug' => 'tiktok',
                'char_limit' => 2200, // TODO-VERIFY
                'image_ratios' => ['9:16'],
                'style_rules' => 'Bahasa santai/kasual, kalimat pembuka yang memikat (hook), dan ramah generasi muda.',
            ],
            [
                'name' => 'YouTube',
                'slug' => 'youtube',
                'char_limit' => 5000, // TODO-VERIFY
                'image_ratios' => ['16:9', '9:16'],
                'style_rules' => 'Deskripsi video berita yang lengkap dan informatif, menyertakan ringkasan isi liputan.',
            ],
        ];

        foreach ($platforms as $platform) {
            Platform::updateOrCreate(
                ['slug' => $platform['slug']],
                $platform
            );
        }
    }
}

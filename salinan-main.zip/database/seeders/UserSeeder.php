<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Jalankan proses seeding akun pengguna redaksi internal.
     */
    public function run(): void
    {
        $admin = config('seeding.admin');
        $editor = config('seeding.editor');

        if (
            empty($admin['name']) || empty($admin['email']) || empty($admin['password']) ||
            empty($editor['name']) || empty($editor['email']) || empty($editor['password'])
        ) {
            throw new \RuntimeException(
                'Konfigurasi akun seeder tidak lengkap. Pastikan SEEDER_ADMIN_* dan SEEDER_EDITOR_* telah diatur pada file .env.'
            );
        }

        User::updateOrCreate(
            ['email' => $admin['email']],
            [
                'name' => $admin['name'],
                'password' => Hash::make($admin['password']),
            ]
        );

        User::updateOrCreate(
            ['email' => $editor['email']],
            [
                'name' => $editor['name'],
                'password' => Hash::make($editor['password']),
            ]
        );
    }
}

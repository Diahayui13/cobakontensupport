<?php

namespace Database\Seeders;

use App\Models\ContentType;
use Illuminate\Database\Seeder;

class ContentTypeSeeder extends Seeder
{
    /**
     * Tiga jenis konten contoh awal sebagai satu sumber kebenaran (Single Source of Truth).
     * Penanda status contoh dicatat pada dokumentasi/UI, bukan pada teks prompt.
     */
    public const DEFAULT_TYPES = [
        [
            'name' => 'Berita Lugas',
            'style_rules' => 'Gunakan struktur piramida terbalik dengan unsur 5W+1H yang jelas dan lugas. Bahasa baku jurnalistik, kalimat efektif, fokus pada fakta utama tanpa opini atau dramatisasi. Gunakan hanya fakta yang ada di artikel; jangan menambah detail, himbauan, suasana, atau kutipan yang tidak ada di artikel.',
            'example' => 'Peristiwa utama dilaporkan terjadi pada waktu pelaksanaan kegiatan resmi. Pihak berwenang menyatakan proses penanganan telah selesai sesuai rencana.',
        ],
        [
            'name' => 'Breaking News',
            'style_rules' => 'Format kilat dengan penekanan pada urgensi dan informasi paling mutakhir. Kalimat pendek, lugas, langsung ke inti kejadian yang baru saja berlangsung, sertakan situasi terkini hanya jika ada di artikel. Gunakan hanya fakta yang ada di artikel; jangan menambah detail, himbauan, suasana, atau kutipan yang tidak ada di artikel.',
            'example' => 'Informasi terkini mengenai perkembangan situasi di lokasi kejadian. Akses publik sementara disesuaikan selama proses penanganan berlangsung.',
        ],
        [
            'name' => 'Feature',
            'style_rules' => 'Pendekatan bercerita (storytelling) dengan sudut pandang humanis dan nada berempati. Menggambarkan suasana dan latar hanya sejauh disebut di artikel, tanpa mengubah fakta. Gunakan hanya fakta yang ada di artikel; jangan menambah detail, himbauan, suasana, atau kutipan yang tidak ada di artikel.',
            'example' => 'Di balik peristiwa yang berlangsung, terdapat dedikasi pekerja harian yang berupaya menjaga kelancaran aktivitas masyarakat sekitar.',
        ],
    ];

    /**
     * Jalankan seeder tiga jenis konten contoh awal.
     */
    public function run(): void
    {
        foreach (self::DEFAULT_TYPES as $type) {
            ContentType::updateOrCreate(
                ['name' => $type['name']],
                [
                    'style_rules' => $type['style_rules'],
                    'example' => $type['example'],
                ]
            );
        }
    }
}

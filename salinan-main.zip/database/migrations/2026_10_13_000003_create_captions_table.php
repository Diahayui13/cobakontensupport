<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('captions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('article_id')->constrained('articles')->onDelete('cascade');
            $table->foreignId('platform_id')->constrained('platforms')->onDelete('cascade');
            $table->integer('attempt_no')->default(1);
            $table->text('ai_text');
            $table->text('final_text')->nullable();
            $table->json('hashtags')->nullable();
            $table->text('summary')->nullable();
            $table->string('status')->default('draf'); // draf, siap, terjadwal, terbit, gagal
            $table->timestamp('ready_at')->nullable();
            $table->timestamps();

            $table->index(['article_id', 'platform_id', 'attempt_no']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('captions');
    }
};

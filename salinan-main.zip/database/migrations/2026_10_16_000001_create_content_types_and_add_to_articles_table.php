<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Jalankan migrasi: buat tabel content_types, tambah foreign key di articles, dan migrasikan data artikel eksisting.
     */
    public function up(): void
    {
        // 1. Buat tabel content_types
        Schema::create('content_types', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->text('style_rules');
            $table->text('example')->nullable();
            $table->timestamps();
        });

        // 2. Tambah kolom foreign key content_type_id pada articles (nullable, kolom content_type lama TETAP ADA)
        Schema::table('articles', function (Blueprint $table) {
            $table->foreignId('content_type_id')
                ->nullable()
                ->after('content_type')
                ->constrained('content_types')
                ->nullOnDelete();
        });

        // 3. Masukkan tiga jenis konten contoh awal (menggunakan Single Source of Truth dari ContentTypeSeeder)
        (new \Database\Seeders\ContentTypeSeeder())->run();

        // 4. Migrasi data artikel eksisting berdasarkan label dropdown lama
        $beritaLugas = DB::table('content_types')->where('name', 'Berita Lugas')->first();
        $breakingNews = DB::table('content_types')->where('name', 'Breaking News')->first();
        $feature = DB::table('content_types')->where('name', 'Feature')->first();

        if ($beritaLugas) {
            DB::table('articles')
                ->whereIn('content_type', ['1', 'hard_news'])
                ->update(['content_type_id' => $beritaLugas->id]);
        }

        if ($breakingNews) {
            DB::table('articles')
                ->whereIn('content_type', ['2', 'breaking_news'])
                ->update(['content_type_id' => $breakingNews->id]);
        }

        if ($feature) {
            DB::table('articles')
                ->whereIn('content_type', ['3', 'feature'])
                ->update(['content_type_id' => $feature->id]);
        }

        // Catatan: Nilai string tak dikenal dibiarkan dengan content_type_id = NULL
    }

    /**
     * Balikkan migrasi: hapus foreign key dan kolom content_type_id, lalu hapus tabel content_types.
     */
    public function down(): void
    {
        Schema::table('articles', function (Blueprint $table) {
            $table->dropForeign(['content_type_id']);
            $table->dropColumn('content_type_id');
        });

        Schema::dropIfExists('content_types');
    }
};

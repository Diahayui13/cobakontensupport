<script setup>
import { computed } from "vue";
import { Link, router, usePage } from "@inertiajs/vue3";

const page = usePage();

const authUser = computed(() => page.props.auth?.user);

const userInitials = computed(() => {
  const name = authUser.value?.name || "Editor";
  return name
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
});

const isKontenActive = computed(() => {
  return page.url.startsWith("/konten") || page.url === "/";
});

const isKalenderActive = computed(() => {
  return page.url.startsWith("/kalender");
});

const isJenisKontenActive = computed(() => {
  return page.url.startsWith("/jenis-konten");
});

const handleLogout = () => {
  router.post("/logout");
};
</script>

<template>
  <div class="bg-slate-50 text-slate-800 min-h-screen flex antialiased">
    <!-- Sidebar Navigasi Desktop -->
    <aside class="w-64 bg-slate-900 text-slate-300 flex flex-col justify-between shrink-0 min-h-screen">
      <div>
        <!-- Header Brand -->
        <div class="h-16 flex items-center px-6 gap-3 border-b border-slate-800">
          <div class="w-8 h-8 bg-red-600 text-white font-bold text-sm rounded-lg flex items-center justify-center shadow-sm">RB</div>
          <div>
            <span class="font-bold text-white tracking-wide text-base block leading-none">kontensupport</span>
            <span class="text-[10px] text-slate-400">Radar Bojonegoro</span>
          </div>
        </div>

        <!-- Menu Navigasi -->
        <nav class="p-4 space-y-1">
          <Link href="/konten" :class="['flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors', isKontenActive ? 'bg-red-600 text-white shadow-sm' : 'hover:bg-slate-800 text-slate-300 hover:text-white']">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
            </svg>
            <span>Daftar Konten</span>
          </Link>

          <Link href="/kalender" :class="['flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors', isKalenderActive ? 'bg-red-600 text-white shadow-sm' : 'hover:bg-slate-800 text-slate-300 hover:text-white']">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <span>Kalender Jadwal</span>
          </Link>

          <Link href="/jenis-konten" :class="['flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors', isJenisKontenActive ? 'bg-red-600 text-white shadow-sm' : 'hover:bg-slate-800 text-slate-300 hover:text-white']">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
            </svg>
            <span>Jenis Konten</span>
          </Link>
        </nav>
      </div>

      <!-- Profil & Logout -->
      <div class="p-4 border-t border-slate-800">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-semibold text-xs text-white">
              {{ userInitials }}
            </div>
            <div class="overflow-hidden">
              <p class="text-xs font-semibold text-white truncate">{{ authUser?.name || 'Editor Naskah' }}</p>
              <p class="text-[10px] text-slate-400 truncate">{{ authUser?.email || 'editor@radarbojonegoro.id' }}</p>
            </div>
          </div>
        </div>
        <button
          type="button"
          @click="handleLogout"
          class="flex items-center justify-center gap-2 w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
        >
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
          <span>Keluar</span>
        </button>
      </div>
    </aside>

    <!-- Konten Utama Desktop -->
    <main class="flex-1 flex flex-col min-h-screen overflow-y-auto bg-slate-50">
      <slot />
    </main>
  </div>
</template>


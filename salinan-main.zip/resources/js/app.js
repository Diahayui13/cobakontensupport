import "../css/app.css";
import "primeicons/primeicons.css";

import { createApp, h } from "vue";
import { createInertiaApp } from "@inertiajs/vue3";
import PrimeVue from "primevue/config";
import Aura from "@primevue/themes/aura";

function getInitialPage() {
  if (typeof window === "undefined") return null;
  const script = document.querySelector('script[data-page="app"][type="application/json"]');
  if (script?.textContent) {
    try {
      return JSON.parse(script.textContent);
    } catch (e) {
      console.warn("Could not parse script[data-page] JSON", e);
    }
  }
  const el = document.getElementById("app");
  if (el?.dataset?.page) {
    try {
      return JSON.parse(el.dataset.page);
    } catch (e) {
      console.warn("Could not parse dataset.page JSON", e);
    }
  }
  return null;
}

const initialPage = getInitialPage();

createInertiaApp({
  page: initialPage || void 0,
  title: (title) => (title ? `${title} - Radar Bojonegoro` : "Radar Bojonegoro Konten Support"),
  resolve: async (name) => {
    const pages = import.meta.glob("./Pages/**/*.vue");
    const pageResolver = pages[`./Pages/${name}.vue`];
    if (!pageResolver) {
      throw new Error(`Page not found: ${name}`);
    }
    const module = typeof pageResolver === "function" ? await pageResolver() : pageResolver;
    return module.default || module;
  },
  setup({ el, App, props, plugin }) {
    createApp({ render: () => h(App, props) })
      .use(plugin)
      .use(PrimeVue, {
        theme: {
          preset: Aura,
          options: {
            darkModeSelector: ".dark",
          },
        },
      })
      .mount(el);
  },
});


<script setup>
import { ref, onMounted } from "vue";
import Card from "primevue/card";
import Button from "primevue/button";
import Textarea from "primevue/textarea";
import { Canvas, Rect } from "fabric";

const articleInput = ref("");
const canvasEl = ref(null);
let fabricCanvas = null;

onMounted(() => {
  if (canvasEl.value) {
    fabricCanvas = new Canvas(canvasEl.value, {
      width: 400,
      height: 400,
      backgroundColor: "#f8fafc",
    });

    // Contoh elemen awal untuk memverifikasi Fabric.js v6
    const rect = new Rect({
      left: 50,
      top: 50,
      fill: "#0284c7",
      width: 100,
      height: 100,
      rx: 8,
      ry: 8,
    });
    fabricCanvas.add(rect);
  }
});
</script>

<template>
  <div class="min-h-screen bg-slate-50 p-6">
    <!-- Header -->
    <header class="mb-8 border-b border-slate-200 pb-4">
      <h1 class="text-2xl font-bold tracking-tight text-slate-800">Radar Bojonegoro — Produksi & Penjadwalan Konten</h1>
      <p class="text-sm text-slate-500">Inertia.js + Vue 3 + PrimeVue v4 + Tailwind CSS + Fabric.js v6</p>
    </header>

    <!-- Grid Layout -->
    <div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <!-- Kolom Kiri: Input Redaksi (PrimeVue + Tailwind) -->
      <Card class="shadow-sm">
        <template #title>
          <span class="text-lg font-semibold text-slate-800">Input Artikel Berita</span>
        </template>
        <template #content>
          <div class="flex flex-col gap-4">
            <div>
              <label class="mb-1 block text-xs font-semibold uppercase text-slate-500"> Isi Artikel CMS </label>
              <Textarea v-model="articleInput" rows="8" class="w-full" placeholder="Tempel naskah artikel berita di sini..." />
            </div>
            <div class="flex justify-end gap-2">
              <Button label="Reset" severity="secondary" outlined />
              <Button label="Generate Caption (Gemini)" icon="pi pi-sparkles" />
            </div>
          </div>
        </template>
      </Card>

      <!-- Kolom Kanan: Canvas Engine (Fabric.js v6+) -->
      <Card class="shadow-sm">
        <template #title>
          <span class="text-lg font-semibold text-slate-800">Preview Template Gambar</span>
        </template>
        <template #content>
          <div class="flex flex-col items-center justify-center gap-4">
            <div class="overflow-hidden rounded-lg border border-slate-300 shadow-inner">
              <canvas ref="canvasEl"></canvas>
            </div>
            <p class="text-xs text-slate-400">Canvas Engine: Fabric.js v6 (1:1 Ratio Preview)</p>
          </div>
        </template>
      </Card>
    </div>
  </div>
</template>


<script setup>
import { ref, computed } from "vue";
import { Head, Link } from "@inertiajs/vue3";
import AppLayout from "../../Layouts/AppLayout.vue";

const props = defineProps({
  articles: {
    type: Array,
    default: () => [],
  },
});

const searchQuery = ref("");
const statusFilter = ref("");

const platformBadgeClass = (platform) => {
  switch (platform) {
    case "Instagram":
      return "bg-pink-100 text-pink-700";
    case "Facebook":
      return "bg-blue-100 text-blue-700";
    case "X":
      return "bg-slate-100 text-slate-700";
    case "YouTube":
      return "bg-red-100 text-red-700";
    case "TikTok":
      return "bg-slate-800 text-white";
    default:
      return "bg-slate-100 text-slate-700";
  }
};

const filteredArticles = computed(() => {
  return (props.articles || []).filter((article) => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.value.toLowerCase());
    const matchesStatus = !statusFilter.value || article.status === statusFilter.value;
    return matchesSearch && matchesStatus;
  });
});
</script>

<template>
  <AppLayout>
    <Head title="Daftar Konten" />

    <!-- Topbar -->
    <header class="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0">
      <div>
        <h1 class="text-xl font-bold text-slate-800">Manajemen Artikel & Konten</h1>
        <p class="text-xs text-slate-500">Kelola konversi artikel web menjadi postingan media sosial</p>
      </div>
      <div class="flex items-center gap-3">
        <Link href="/konten/tambah" class="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
          </svg>
          <span>Tambah Konten Baru</span>
        </Link>
      </div>
    </header>

    <!-- Body Section -->
    <div class="p-8 space-y-6 flex-1">
      <!-- Filter & Pencarian -->
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-3 flex-1 min-w-[300px]">
          <div class="relative w-full max-w-md">
            <input v-model="searchQuery" type="text" placeholder="Cari judul artikel..." class="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" />
            <svg class="w-4 h-4 text-slate-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <select v-model="statusFilter" class="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-700 focus:outline-none focus:ring-2 focus:ring-red-500">
            <option value="">Semua Status</option>
            <option value="draf">Draf</option>
            <option value="siap">Siap</option>
            <option value="terjadwal">Terjadwal</option>
            <option value="terbit">Terbit</option>
          </select>
        </div>
        <div class="text-xs text-slate-500">
          Menampilkan <strong>{{ filteredArticles.length }}</strong> artikel aktif
        </div>
      </div>

      <!-- Tabel Daftar Artikel -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table class="w-full text-left text-sm text-slate-600">
          <thead class="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
            <tr>
              <th class="px-6 py-3.5">Judul Artikel & Tanggal</th>
              <th class="px-6 py-3.5">Platform Target</th>
              <th class="px-6 py-3.5">Status Caption</th>
              <th class="px-6 py-3.5">Percobaan AI</th>
              <th class="px-6 py-3.5 text-right">Aksi</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-200">
            <tr v-for="article in filteredArticles" :key="article.id" class="hover:bg-slate-50/75 transition-colors">
              <td class="px-6 py-4">
                <Link :href="`/konten/${article.id}`" class="font-semibold text-slate-900 hover:text-red-600 block line-clamp-1">
                  {{ article.title }}
                </Link>
                <span class="text-xs text-slate-400 mt-0.5 block"> {{ article.created_at }} • Oleh {{ article.author }} </span>
              </td>
              <td class="px-6 py-4">
                <div class="flex items-center gap-1.5 flex-wrap">
                  <span v-for="platform in article.platforms" :key="platform" :class="['px-2 py-0.5 rounded text-[11px] font-medium', platformBadgeClass(platform)]">
                    {{ platform }}
                  </span>
                </div>
              </td>
              <td class="px-6 py-4">
                <span :class="['inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold', article.status_class]">
                  {{ article.status_label }}
                </span>
              </td>
              <td class="px-6 py-4 text-xs text-slate-500 font-mono">
                {{ article.attempt }}
              </td>
              <td class="px-6 py-4 text-right">
                <Link :href="`/konten/${article.id}`" class="inline-flex items-center gap-1 text-xs font-semibold text-red-600 hover:text-red-800">
                  <span>Buka Detail</span>
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </td>
            </tr>

            <tr v-if="filteredArticles.length === 0">
              <td colspan="5" class="px-6 py-8 text-center text-slate-400 text-sm">Tidak ada artikel yang cocok dengan pencarian atau filter.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </AppLayout>
</template>


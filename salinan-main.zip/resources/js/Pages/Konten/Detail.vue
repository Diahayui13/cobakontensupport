<script setup>
import { ref, watch, nextTick, computed } from "vue";
import { Head, Link, router, usePage } from "@inertiajs/vue3";
import AppLayout from "../../Layouts/AppLayout.vue";
import { Canvas, Rect, Textbox } from "fabric";

const props = defineProps({
  article: {
    type: Object,
    default: null,
  },
  platforms: {
    type: Array,
    default: () => [],
  },
  captions: {
    type: Object,
    default: () => ({}),
  },
  contentTypes: {
    type: Array,
    default: () => [],
  },
});

const page = usePage();
const flashSuccess = computed(() => page.props.flash?.success);
const flashError = computed(() => page.props.flash?.error);

const isNew = computed(() => !props.article);
const activeTab = ref(isNew.value ? "artikel" : "caption");
const isGeneratingAll = ref(false);
const regeneratingMap = ref({});
const savingMap = ref({});

// Tab 1: Form Naskah
const form = ref({
  title: props.article?.title || "",
  body: props.article?.body || "",
  notes_for_ai: props.article?.notes_for_ai || "",
  content_type_id: isNew.value ? null : (props.article?.content_type_id ?? null),
  target_platforms: {
    instagram: true,
    facebook: true,
    x: true,
    tiktok: true,
    youtube: true,
  },
});

const selectedContentType = computed(() => {
  return props.contentTypes?.find((ct) => ct.id === form.value.content_type_id);
});

// Tab 2: Caption Data Real
const localCaptions = ref({});

const syncCaptionsFromProps = () => {
  const result = {};
  if (props.captions && Object.keys(props.captions).length > 0) {
    for (const [key, item] of Object.entries(props.captions)) {
      result[key] = {
        ...item,
        editText: item.final_text || item.ai_text || "",
        copied: false,
      };
    }
  }
  localCaptions.value = result;
};

syncCaptionsFromProps();

watch(
  () => props.captions,
  () => {
    syncCaptionsFromProps();
  },
  { deep: true },
);

const handleGenerateAi = () => {
  if (!form.value.title.trim() || !form.value.body.trim()) {
    alert("Harap lengkapi judul dan isi artikel terlebih dahulu.");
    return;
  }

  const selectedSlugs = Object.keys(form.value.target_platforms).filter((key) => form.value.target_platforms[key]);

  if (selectedSlugs.length === 0) {
    alert("Pilih minimal satu platform target media sosial.");
    return;
  }

  isGeneratingAll.value = true;

  const targetUrl = props.article?.id ? `/articles/${props.article.id}/regenerate` : "/konten";

  router.post(
    targetUrl,
    {
      title: form.value.title,
      body: form.value.body,
      notes_for_ai: form.value.notes_for_ai,
      content_type_id: form.value.content_type_id,
      target_platforms: selectedSlugs,
    },
    {
      onFinish: () => {
        isGeneratingAll.value = false;
      },
      onSuccess: () => {
        activeTab.value = "caption";
      },
    },
  );
};

const handleSaveDraft = (key) => {
  const item = localCaptions.value[key];
  if (!item?.id) return;

  savingMap.value[key] = true;
  router.put(
    `/captions/${item.id}`,
    {
      final_text: item.editText,
      status: "draf",
    },
    {
      preserveScroll: true,
      onFinish: () => {
        savingMap.value[key] = false;
      },
    },
  );
};

const handleReadyToUse = (key) => {
  const item = localCaptions.value[key];
  if (!item?.id) return;

  item.status = "siap";
  if (navigator.clipboard) {
    navigator.clipboard.writeText(item.editText);
  }
  item.copied = true;
  setTimeout(() => {
    item.copied = false;
  }, 2500);

  router.put(
    `/captions/${item.id}`,
    {
      final_text: item.editText,
      status: "siap",
    },
    {
      preserveScroll: true,
    },
  );
};

// Buat Ulang dengan animasi tanpa alert
const handleRegenerate = (key) => {
  const item = localCaptions.value[key];
  if (!props.article?.id || !item?.platform_id) return;

  regeneratingMap.value[key] = true;

  router.post(
    `/articles/${props.article.id}/platforms/${item.platform_id}/regenerate`,
    {},
    {
      preserveScroll: true,
      onFinish: () => {
        regeneratingMap.value[key] = false;
      },
    },
  );
};

// Tab 3: Visual Canvas (Fabric.js v6)
const canvasEl = ref(null);
let fabricCanvas = null;
const selectedRatio = ref("1:1");
const zoomVal = ref(100);
const posX = ref(0);
const posY = ref(0);

const initCanvas = () => {
  if (canvasEl.value && !fabricCanvas) {
    fabricCanvas = new Canvas(canvasEl.value, {
      width: 400,
      height: 400,
      backgroundColor: "#0f172a",
    });

    const headerBg = new Rect({
      left: 20,
      top: 20,
      width: 140,
      height: 28,
      fill: "#dc2626",
      rx: 4,
      ry: 4,
    });
    fabricCanvas.add(headerBg);

    const logoText = new Textbox("RADAR BOJONEGORO", {
      left: 26,
      top: 27,
      fontSize: 11,
      fontWeight: "bold",
      fill: "#ffffff",
      editable: false,
    });
    fabricCanvas.add(logoText);

    const currentHeadline = props.article?.title || form.value.title || "Judul Berita Radar Bojonegoro";
    const headline = new Textbox(currentHeadline, {
      left: 20,
      top: 270,
      width: 360,
      fontSize: 16,
      fontWeight: "bold",
      fill: "#ffffff",
      editable: true,
    });
    fabricCanvas.add(headline);
  }
};

watch(activeTab, (newTab) => {
  if (newTab === "visual") {
    nextTick(() => {
      initCanvas();
    });
  }
});

const downloadCanvasPng = () => {
  if (fabricCanvas) {
    const dataURL = fabricCanvas.toDataURL({ format: "png", quality: 1 });
    const link = document.createElement("a");
    link.download = `radar-bojonegoro-${props.article?.id || "konten"}.png`;
    link.href = dataURL;
    link.click();
  }
};

// Tab 4: Jadwal
const schedulePlatform = ref("Instagram Feed");
const scheduleDate = ref("2026-10-13");
const scheduleTime = ref("09:00");
const scheduleNotes = ref("");

const handleSaveSchedule = () => {
  alert("Jadwal akan diaktifkan penuh pada Iterasi 3 (Modul Kalender Konten).");
};

const defaultPlatforms = [
  { slug: "instagram", name: "Instagram Feed", code: "IG", color: "bg-pink-600", meta: "Rasio: 1:1, 4:5 • Batas: 2.200 karakter", limit: 2200 },
  { slug: "x", name: "X (Twitter)", code: "X", color: "bg-black", meta: "Rasio: 16:9, 1:1 • Batas Ketat: 280 karakter", limit: 280 },
  { slug: "facebook", name: "Facebook Page", code: "FB", color: "bg-blue-600", meta: "Rasio: 1:1, 16:9 • Batas: 63.206 karakter", limit: 63206 },
  { slug: "tiktok", name: "TikTok (Unggah Manual)", code: "TT", color: "bg-slate-800", meta: "Rasio: 9:16 • Batas: 2.200 karakter", limit: 2200 },
  { slug: "youtube", name: "YouTube (Deskripsi Video)", code: "YT", color: "bg-red-600", meta: "Rasio: 16:9, 9:16 • Batas: 5.000 karakter", limit: 5000 },
];

const platformBadgeInfo = (slug) => {
  const found = defaultPlatforms.find((p) => p.slug === slug);
  if (found) {
    return { code: found.code, color: found.color, meta: found.meta, limit: found.limit };
  }
  return { code: (slug || "").toUpperCase(), color: "bg-slate-700", meta: "Batas platform", limit: 2200 };
};

const orderedCaptions = computed(() => {
  const list = [];
  const slugs = ["instagram", "x", "facebook", "tiktok", "youtube"];
  for (const slug of slugs) {
    if (localCaptions.value[slug]) {
      list.push({ key: slug, ...localCaptions.value[slug] });
    }
  }
  for (const [slug, item] of Object.entries(localCaptions.value)) {
    if (!slugs.includes(slug)) {
      list.push({ key: slug, ...item });
    }
  }
  return list;
});

const activeAttempt = computed(() => {
  let max = 1;
  for (const item of Object.values(localCaptions.value)) {
    if (item.attempt_no && item.attempt_no > max) {
      max = item.attempt_no;
    }
  }
  return max;
});

const globalStatus = computed(() => {
  const items = Object.values(localCaptions.value);
  if (!items.length) {
    return { label: "Draf Baru", badgeClass: "bg-slate-100 text-slate-700", textClass: "text-slate-600" };
  }
  if (items.some((c) => c.status === "terbit")) {
    return { label: "Terbit", badgeClass: "bg-blue-100 text-blue-800", textClass: "text-blue-600" };
  }
  if (items.some((c) => c.status === "terjadwal")) {
    return { label: "Terjadwal", badgeClass: "bg-amber-100 text-amber-800", textClass: "text-amber-600" };
  }
  if (items.every((c) => c.status === "siap")) {
    return { label: "Siap Pakai", badgeClass: "bg-emerald-100 text-emerald-800", textClass: "text-emerald-600" };
  }
  return { label: "Draf", badgeClass: "bg-slate-200 text-slate-700", textClass: "text-slate-600" };
});

const ratioDimensions = computed(() => {
  switch (selectedRatio.value) {
    case "1:1":
      return "1080x1080";
    case "4:5":
      return "1080x1350";
    case "9:16":
      return "1080x1920";
    case "16:9":
      return "1920x1080";
    default:
      return "1080x1080";
  }
});

const platformTextColor = (key) => {
  switch (key) {
    case "instagram":
      return "text-pink-700";
    case "facebook":
      return "text-blue-700";
    case "youtube":
      return "text-red-700";
    default:
      return "text-slate-800";
  }
};
</script>

<template>
  <AppLayout>
    <Head :title="article ? article.title : 'Tambah Konten Baru'" />

    <!-- Notifikasi Pesan Flash -->
    <div v-if="flashSuccess" class="bg-emerald-50 border-b border-emerald-200 px-8 py-3 text-xs text-emerald-800 font-medium flex items-center justify-between">
      <span>{{ flashSuccess }}</span>
    </div>
    <div v-if="flashError" class="bg-red-50 border-b border-red-200 px-8 py-3 text-xs text-red-800 font-medium flex items-center justify-between">
      <span>{{ flashError }}</span>
    </div>

    <!-- Topbar & Navigasi Tab -->
    <header class="bg-white border-b border-slate-200 px-8 pt-4 shrink-0">
      <div class="flex items-center justify-between pb-3">
        <div class="flex items-center gap-3">
          <Link href="/konten" class="text-slate-400 hover:text-slate-600 transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </Link>
          <div>
            <h1 class="text-lg font-bold text-slate-900 leading-tight">
              {{ article ? article.title : form.title || "Jembatan Baru Rajekwesi Diresmikan, Urai Kemacetan Akses Selatan Bojonegoro" }}
            </h1>
            <p class="text-xs text-slate-500 mt-0.5">
              <span v-if="article"
                >Dibuat: {{ article.created_at }} • Status Global: <span :class="['font-semibold', globalStatus.textClass]">{{ globalStatus.label }}</span></span
              >
              <span v-else>Dibuat: Baru • Status Global: <span class="font-semibold text-slate-600">Draf Baru</span></span>
            </p>
          </div>
        </div>
        <div class="flex items-center gap-2">
          <span :class="['inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold', globalStatus.badgeClass]">
            {{ globalStatus.label }}
          </span>
        </div>
      </div>

      <!-- Tab Bar -->
      <div class="flex items-center gap-8 border-t border-slate-100 pt-1 text-sm font-semibold">
        <button @click="activeTab = 'artikel'" :class="['cursor-pointer transition-colors', activeTab === 'artikel' ? 'text-red-600 border-b-2 border-red-600 py-3' : 'text-slate-500 hover:text-slate-800 py-3']">1. Naskah Artikel</button>
        <button @click="activeTab = 'caption'" :class="['cursor-pointer transition-colors', activeTab === 'caption' ? 'text-red-600 border-b-2 border-red-600 py-3' : 'text-slate-500 hover:text-slate-800 py-3']">2. Caption Media Sosial (AI)</button>
        <button @click="activeTab = 'visual'" :class="['cursor-pointer transition-colors', activeTab === 'visual' ? 'text-red-600 border-b-2 border-red-600 py-3' : 'text-slate-500 hover:text-slate-800 py-3']">3. Template Visual Gambar</button>
        <button @click="activeTab = 'jadwal'" :class="['cursor-pointer transition-colors', activeTab === 'jadwal' ? 'text-red-600 border-b-2 border-red-600 py-3' : 'text-slate-500 hover:text-slate-800 py-3']">4. Jadwal & Posting</button>
      </div>
    </header>

    <!-- Container Isi Tab -->
    <div class="p-8 flex-1">
      <!-- TAB 1: ARTIKEL -->
      <div v-show="activeTab === 'artikel'" class="max-w-4xl bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-5">
        <h2 class="text-base font-bold text-slate-800 border-b pb-2">Informasi & Naskah Berita Terbit</h2>

        <!-- Peringatan Tetap Privasi Naskah & AI Pihak Ketiga -->
        <div class="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-start gap-2.5">
          <svg class="w-4 h-4 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <span class="leading-relaxed">Jangan menempelkan naskah yang belum terbit atau data pribadi narasumber. Teks yang dimasukkan dikirim ke layanan AI pihak ketiga.</span>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Judul Artikel (dari CMS Web) </label>
          <input v-model="form.title" type="text" placeholder="Masukkan judul naskah berita..." class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-red-500" />
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Jenis Konten (Gaya Bahasa) </label>
            <select v-model="form.content_type_id" class="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500">
              <option :value="null">-- Tanpa Jenis Konten --</option>
              <option v-for="ct in (contentTypes || [])" :key="ct.id" :value="ct.id">
                {{ ct.name }}
              </option>
            </select>
            <p v-if="selectedContentType" class="text-xs text-slate-500 mt-1.5 italic">
              {{ selectedContentType.style_rules }}
            </p>
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Platform Target </label>
            <div class="flex items-center gap-4 pt-2 flex-wrap">
              <label class="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 cursor-pointer">
                <input v-model="form.target_platforms.instagram" type="checkbox" class="rounded text-red-600 focus:ring-red-500" />
                Instagram
              </label>
              <label class="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 cursor-pointer">
                <input v-model="form.target_platforms.facebook" type="checkbox" class="rounded text-red-600 focus:ring-red-500" />
                Facebook
              </label>
              <label class="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 cursor-pointer">
                <input v-model="form.target_platforms.x" type="checkbox" class="rounded text-red-600 focus:ring-red-500" />
                X (Twitter)
              </label>
              <label class="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 cursor-pointer">
                <input v-model="form.target_platforms.tiktok" type="checkbox" class="rounded text-red-600 focus:ring-red-500" />
                TikTok
              </label>
              <label class="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 cursor-pointer">
                <input v-model="form.target_platforms.youtube" type="checkbox" class="rounded text-red-600 focus:ring-red-500" />
                YouTube
              </label>
            </div>
          </div>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Isi Artikel Lengkap </label>
          <textarea v-model="form.body" rows="8" placeholder="Tempel seluruh naskah berita di sini..." class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 leading-relaxed font-sans focus:outline-none focus:ring-2 focus:ring-red-500"></textarea>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Catatan Tambahan untuk AI (Opsional) </label>
          <input v-model="form.notes_for_ai" type="text" class="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500" placeholder="Contoh: Tekankan kutipan bupati dan selesainya 2 pekan lebih cepat." />
        </div>

        <div class="pt-2 flex justify-end">
          <button type="button" :disabled="isGeneratingAll" @click="handleGenerateAi" class="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:bg-slate-400 text-white font-semibold rounded-lg shadow-sm text-sm flex items-center gap-2 cursor-pointer transition-colors">
            <svg v-if="isGeneratingAll" class="w-4 h-4 animate-spin text-white" fill="none" viewBox="0 0 24 24">
              <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
              <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
            </svg>
            <svg v-else class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span>{{ isGeneratingAll ? "Menghubungi Gemini AI & Menyimpan..." : "Buat Caption AI Semua Platform" }}</span>
          </button>
        </div>
      </div>

      <!-- TAB 2: CAPTION (FOKUS UTAMA) -->
      <div v-show="activeTab === 'caption'" class="space-y-6">
        <!-- Pemberitahuan Prinsip Alur Kerja -->
        <div class="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg text-xs text-blue-900 flex items-start justify-between">
          <div><strong class="font-bold">Prinsip Alur Kerja:</strong> Teks asli AI (<code>ai_text</code>) disimpan permanen untuk analisis. Suntingan dilakukan pada kolom teks final. Tekan <strong>"Siap Pakai"</strong> untuk mengunci draf sebelum dapat dijadwalkan atau diterbitkan.</div>
          <span class="text-[11px] font-mono text-blue-700 bg-blue-100 px-2 py-0.5 rounded">Percobaan Aktif: #{{ activeAttempt }}</span>
        </div>

        <!-- Jika belum ada caption -->
        <div v-if="Object.keys(localCaptions).length === 0" class="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <p class="text-sm font-semibold text-slate-700 mb-2">Belum ada caption AI untuk artikel ini.</p>
          <p class="text-xs text-slate-400 mb-4">Silakan kembali ke Tab 1 (Naskah Artikel) dan tekan tombol "Buat Caption AI Semua Platform".</p>
          <button type="button" @click="activeTab = 'artikel'" class="px-4 py-2 bg-red-600 text-white text-xs font-semibold rounded-lg hover:bg-red-700 cursor-pointer">Buka Tab 1 Naskah</button>
        </div>

        <!-- Grid Kartu Platform Real -->
        <div v-else class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div v-for="item in orderedCaptions" :key="item.key" class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between relative overflow-hidden">
            <!-- Animasi Loading saat Buat Ulang Berjalan -->
            <div v-if="regeneratingMap[item.key]" class="absolute inset-0 bg-slate-900/60 backdrop-blur-xs z-20 flex flex-col items-center justify-center p-6 text-center animate-fade-in">
              <div class="w-10 h-10 border-4 border-red-200 border-t-red-600 rounded-full animate-spin mb-3"></div>
              <p class="text-xs font-bold text-white tracking-wide">Sedang Membuat Variasi AI Baru...</p>
              <p class="text-[11px] text-slate-300 mt-1">Menghubungi Gemini AI khusus untuk {{ item.platform_name }}</p>
            </div>

            <div>
              <!-- Header Kartu Platform -->
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div class="flex items-center gap-2.5">
                  <div :class="['w-7 h-7 rounded-lg text-white flex items-center justify-center font-bold text-xs', platformBadgeInfo(item.key).color]">
                    {{ platformBadgeInfo(item.key).code }}
                  </div>
                  <div>
                    <h3 class="font-bold text-slate-800 text-sm">{{ item.platform_name }}</h3>
                    <p class="text-[11px] text-slate-400">{{ platformBadgeInfo(item.key).meta }}</p>
                  </div>
                </div>
                <div>
                  <span v-if="item.status === 'siap'" class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800"> Siap Pakai </span>
                  <span v-else class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-200 text-slate-700"> Draf </span>
                </div>
              </div>

              <!-- Teks Asli AI (Hanya Baca / ai_text) -->
              <div class="mb-4">
                <div class="flex items-center justify-between mb-1">
                  <label class="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <span>Teks Asli Gemini AI</span>
                    <span class="font-normal text-slate-400">(Hanya Baca / ai_text)</span>
                  </label>
                  <span class="text-[10px] text-slate-400 font-mono">attempt #{{ item.attempt_no }}</span>
                </div>
                <div class="p-3 bg-slate-100 border border-slate-200 rounded-lg text-xs text-slate-600 font-sans leading-relaxed select-text cursor-default whitespace-pre-line">
                  {{ item.ai_text }}
                </div>
              </div>

              <!-- Kolom Suntingan Pengguna (final_text) -->
              <div>
                <div class="flex items-center justify-between mb-1">
                  <label class="text-[11px] font-bold text-slate-700 uppercase tracking-wider"> Kolom Suntingan Final (final_text) </label>
                  <!-- Live Character Counter -->
                  <span class="text-xs font-mono font-medium text-slate-500" :class="[(item.editText || '').length > item.limit ? 'text-red-600 font-bold' : item.limit - (item.editText || '').length < 30 ? 'text-amber-600 font-semibold' : 'text-slate-500']">
                    <span>{{ (item.editText || "").length }}</span> / <span>{{ item.limit }}</span> karakter
                  </span>
                </div>
                <textarea v-model="item.editText" @input="item.status = 'draf'" rows="6" class="w-full p-3 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 leading-relaxed focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all font-sans"></textarea>
              </div>
            </div>

            <!-- Baris Tombol Aksi -->
            <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
              <!-- Tombol Buat Ulang dengan animasi spinner tanpa alert -->
              <button
                type="button"
                :disabled="regeneratingMap[item.key]"
                @click="handleRegenerate(item.key)"
                class="px-3 py-1.5 border border-slate-300 hover:bg-slate-100 disabled:opacity-60 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Buat draf baru dengan AI untuk platform ini"
              >
                <svg v-if="regeneratingMap[item.key]" class="w-3.5 h-3.5 animate-spin text-red-600" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                </svg>
                <svg v-else class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                <span>{{ regeneratingMap[item.key] ? "Memproses AI..." : "Buat Ulang" }}</span>
              </button>

              <div class="flex items-center gap-2">
                <button type="button" :disabled="savingMap[item.key]" @click="handleSaveDraft(item.key)" class="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 disabled:opacity-60 text-slate-800 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5">
                  <svg v-if="savingMap[item.key]" class="w-3 h-3 animate-spin text-slate-700" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                  </svg>
                  <span>{{ savingMap[item.key] ? "Menyimpan..." : "Simpan Draf" }}</span>
                </button>
                <button type="button" @click="handleReadyToUse(item.key)" class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer">
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <span>{{ item.copied ? "Tersalin ke Clipboard!" : "Siap Pakai" }}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- TAB 3: VISUAL -->
      <div v-show="activeTab === 'visual'" class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Panel Kontrol Template Visual -->
        <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-5">
          <h2 class="text-sm font-bold text-slate-800 border-b pb-2">Pengaturan Template Gambar Canvas</h2>

          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2"> Unggah Foto Berita </label>
            <input type="file" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-red-50 file:text-red-700 hover:file:bg-red-100 cursor-pointer" />
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2"> Pilih Rasio Kanvas </label>
            <div class="grid grid-cols-2 gap-2 text-xs">
              <label :class="['p-2.5 rounded-lg flex items-center gap-2 cursor-pointer font-medium border transition-colors', selectedRatio === '1:1' ? 'border-red-500 bg-red-50/50 text-red-900' : 'border-slate-200 text-slate-700 hover:bg-slate-50']">
                <input v-model="selectedRatio" type="radio" value="1:1" class="text-red-600" />
                1:1 Persegi (Feed IG/FB)
              </label>
              <label :class="['p-2.5 rounded-lg flex items-center gap-2 cursor-pointer font-medium border transition-colors', selectedRatio === '4:5' ? 'border-red-500 bg-red-50/50 text-red-900' : 'border-slate-200 text-slate-700 hover:bg-slate-50']">
                <input v-model="selectedRatio" type="radio" value="4:5" class="text-red-600" />
                4:5 Potret (Feed IG)
              </label>
              <label :class="['p-2.5 rounded-lg flex items-center gap-2 cursor-pointer font-medium border transition-colors', selectedRatio === '9:16' ? 'border-red-500 bg-red-50/50 text-red-900' : 'border-slate-200 text-slate-700 hover:bg-slate-50']">
                <input v-model="selectedRatio" type="radio" value="9:16" class="text-red-600" />
                9:16 Story / Reels
              </label>
              <label :class="['p-2.5 rounded-lg flex items-center gap-2 cursor-pointer font-medium border transition-colors', selectedRatio === '16:9' ? 'border-red-500 bg-red-50/50 text-red-900' : 'border-slate-200 text-slate-700 hover:bg-slate-50']">
                <input v-model="selectedRatio" type="radio" value="16:9" class="text-red-600" />
                16:9 Lanskap (X / Web)
              </label>
            </div>
          </div>

          <div class="space-y-3 pt-2 border-t border-slate-100">
            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider"> Penyesuaian Posisi Foto </label>
            <div>
              <div class="flex justify-between text-xs text-slate-500 mb-1">
                <span>Perbesaran (Zoom)</span>
                <span>{{ zoomVal }}%</span>
              </div>
              <input v-model="zoomVal" type="range" min="50" max="200" class="w-full accent-red-600" />
            </div>
            <div>
              <div class="flex justify-between text-xs text-slate-500 mb-1">
                <span>Geser Horizontal (X)</span>
                <span>{{ posX }} px</span>
              </div>
              <input v-model="posX" type="range" min="-100" max="100" class="w-full accent-red-600" />
            </div>
            <div>
              <div class="flex justify-between text-xs text-slate-500 mb-1">
                <span>Geser Vertikal (Y)</span>
                <span>{{ posY }} px</span>
              </div>
              <input v-model="posY" type="range" min="-100" max="100" class="w-full accent-red-600" />
            </div>
          </div>

          <div class="pt-4 border-t border-slate-100">
            <button type="button" @click="downloadCanvasPng" class="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              <span>Unduh Gambar PNG (1080x1080)</span>
            </button>
          </div>
        </div>

        <!-- Pratinjau Kanvas Desktop -->
        <div class="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col items-center justify-center">
          <p class="text-xs font-semibold text-slate-400 mb-3">Pratinjau Hasil Kanvas (Fabric.js Engine v6 di Sisi Browser)</p>

          <div class="overflow-hidden rounded-lg border-4 border-slate-800 shadow-xl bg-slate-900">
            <canvas ref="canvasEl"></canvas>
          </div>
        </div>
      </div>

      <!-- TAB 4: JADWAL -->
      <div v-show="activeTab === 'jadwal'" class="max-w-4xl bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
        <div>
          <h2 class="text-base font-bold text-slate-800">Atur Jadwal Posting</h2>
          <p class="text-xs text-slate-500">Jadwalkan penayangan konten media sosial untuk tayang di kalender terpadu</p>
        </div>

        <div class="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-4">
          <div class="grid grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Platform </label>
              <select v-model="schedulePlatform" class="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800">
                <option v-for="item in orderedCaptions" :key="item.key" :value="item.platform_name">{{ item.platform_name }} ({{ item.status === "siap" ? "Siap Pakai" : "Draf" }})</option>
              </select>
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Tanggal Tayang </label>
              <input v-model="scheduleDate" type="date" class="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800" />
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Jam (WIB) </label>
              <input v-model="scheduleTime" type="time" class="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800" />
            </div>
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1"> Catatan Jadwal (Opsional) </label>
            <input v-model="scheduleNotes" type="text" placeholder="Contoh: Jadwalkan bersamaan jam istirahat kantor" class="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800" />
          </div>
          <div class="flex justify-end">
            <button type="button" @click="handleSaveSchedule" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm cursor-pointer transition-colors">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <span>Simpan Jadwal ke Kalender</span>
            </button>
          </div>
        </div>

        <!-- Tabel Status Jadwal Terpasang -->
        <div class="pt-4 border-t border-slate-100">
          <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Status Distribusi Per Platform</h3>
          <div class="border rounded-lg overflow-hidden">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-100 text-slate-700 font-semibold border-b">
                <tr>
                  <th class="px-4 py-2.5">Platform</th>
                  <th class="px-4 py-2.5">Waktu Rencana</th>
                  <th class="px-4 py-2.5">Metode Unggah</th>
                  <th class="px-4 py-2.5">Status</th>
                  <th class="px-4 py-2.5 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                <tr v-for="item in orderedCaptions" :key="item.key">
                  <td :class="['px-4 py-3 font-semibold', platformTextColor(item.key)]">
                    {{ item.platform_name }}
                  </td>
                  <td class="px-4 py-3">{{ item.status === "terjadwal" ? "12 Okt 2026, 09:00 WIB" : "-" }}</td>
                  <td class="px-4 py-3 text-slate-500">{{ item.key === "instagram" || item.key === "facebook" ? "Otomatis / Meta Suite" : "Salin Manual" }}</td>
                  <td class="px-4 py-3">
                    <span :class="['px-2 py-0.5 rounded font-semibold text-[11px]', item.status === 'siap' ? 'bg-emerald-100 text-emerald-800' : item.status === 'terjadwal' ? 'bg-amber-100 text-amber-800' : item.status === 'terbit' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700']">
                      {{ item.status === "siap" ? "Siap Pakai" : item.status === "terjadwal" ? "Terjadwal" : item.status === "terbit" ? "Terbit" : "Draf" }}
                    </span>
                  </td>
                  <td class="px-4 py-3 text-right">
                    <button type="button" @click="handleMarkPublished(item.platform_name)" class="text-red-600 font-semibold hover:underline cursor-pointer">Tandai Terbit</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </AppLayout>
</template>


<script setup>
import { ref } from "vue";
import { Head } from "@inertiajs/vue3";
import AppLayout from "../../Layouts/AppLayout.vue";

const currentMonth = ref("Oktober 2026");

const prevMonth = () => {
  // Demo navigasi bulan
};

const nextMonth = () => {
  // Demo navigasi bulan
};
</script>

<template>
  <AppLayout>
    <Head title="Kalender Jadwal" />

    <!-- Topbar Kalender -->
    <header class="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0">
      <div>
        <h1 class="text-xl font-bold text-slate-800">Kalender Jadwal Penayangan</h1>
        <p class="text-xs text-slate-500">Tampilan agenda bulanan jadwal posting media sosial Radar Bojonegoro</p>
      </div>
      <div class="flex items-center gap-3">
        <div class="flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200 text-xs font-semibold">
          <button @click="prevMonth" class="px-3 py-1.5 rounded-md hover:bg-white text-slate-600 transition-colors cursor-pointer">&lt; Bulan Lalu</button>
          <span class="px-4 py-1.5 text-slate-900 font-bold">{{ currentMonth }}</span>
          <button @click="nextMonth" class="px-3 py-1.5 rounded-md hover:bg-white text-slate-600 transition-colors cursor-pointer">Bulan Depan &gt;</button>
        </div>
      </div>
    </header>

    <!-- Body Kalender Grid Bulanan -->
    <div class="p-8 space-y-4 flex-1">
      <!-- Filter Platform & Legenda -->
      <div class="flex items-center justify-between text-xs">
        <div class="flex items-center gap-3">
          <span class="font-bold text-slate-600">Legenda Platform:</span>
          <span class="inline-flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-pink-500"></span> Instagram</span>
          <span class="inline-flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-blue-600"></span> Facebook</span>
          <span class="inline-flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-slate-900"></span> X (Twitter)</span>
          <span class="inline-flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-red-600"></span> YouTube</span>
        </div>
        <div class="text-slate-400">Tampilan Bulan (FullCalendar Grid)</div>
      </div>

      <!-- Kalender Grid Bulanan (Minggu - Sabtu) -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <!-- Header Hari -->
        <div class="grid grid-cols-7 bg-slate-50 border-b border-slate-200 text-center text-xs font-bold text-slate-700 py-3 uppercase tracking-wider">
          <div>Minggu</div>
          <div>Senin</div>
          <div>Selasa</div>
          <div>Rabu</div>
          <div>Kamis</div>
          <div>Jumat</div>
          <div>Sabtu</div>
        </div>

        <!-- Grid Tanggal -->
        <div class="grid grid-cols-7 divide-x divide-y divide-slate-200 text-xs">
          <!-- Pekan 1 -->
          <div class="min-h-[120px] p-2 bg-slate-50/50 text-slate-400">
            <span class="font-semibold">27</span>
          </div>
          <div class="min-h-[120px] p-2 bg-slate-50/50 text-slate-400">
            <span class="font-semibold">28</span>
          </div>
          <div class="min-h-[120px] p-2 bg-slate-50/50 text-slate-400">
            <span class="font-semibold">29</span>
          </div>
          <div class="min-h-[120px] p-2 bg-slate-50/50 text-slate-400">
            <span class="font-semibold">30</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">1</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">2</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">3</span>
          </div>

          <!-- Pekan 2 -->
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">4</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">5</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">6</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">7</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">8</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">9</span>
          </div>
          <div class="min-h-[120px] p-2 space-y-1">
            <span class="font-semibold text-slate-800">10</span>
            <div class="p-1.5 bg-blue-50 border-l-2 border-blue-600 rounded text-[10px] text-blue-900 font-medium"><span class="font-bold">18:30</span> Persibo Laga Kandang (FB)</div>
          </div>

          <!-- Pekan 3 (Hari Ini & Jadwal Terdekat) -->
          <div class="min-h-[120px] p-2 bg-red-50/30 space-y-1">
            <div class="flex items-center justify-between">
              <span class="font-bold text-red-600">11 (Hari Ini)</span>
              <span class="w-1.5 h-1.5 rounded-full bg-red-600"></span>
            </div>
            <div class="p-1.5 bg-pink-50 border-l-2 border-pink-500 rounded text-[10px] text-pink-900 font-medium"><span class="font-bold">14:20</span> Jembatan Rajekwesi (IG)</div>
            <div class="p-1.5 bg-slate-100 border-l-2 border-slate-900 rounded text-[10px] text-slate-900 font-medium"><span class="font-bold">15:00</span> Jembatan Rajekwesi (X)</div>
          </div>

          <div class="min-h-[120px] p-2 space-y-1">
            <span class="font-semibold text-slate-800">12</span>
            <div class="p-1.5 bg-amber-50 border-l-2 border-amber-500 rounded text-[10px] text-amber-900 font-medium"><span class="font-bold">09:00</span> Festival Geopark (IG & FB)</div>
          </div>

          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">13</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">14</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">15</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">16</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">17</span>
          </div>

          <!-- Pekan 4 -->
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">18</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">19</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">20</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">21</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">22</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">23</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">24</span>
          </div>

          <!-- Pekan 5 -->
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">25</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">26</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">27</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">28</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">29</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">30</span>
          </div>
          <div class="min-h-[120px] p-2">
            <span class="font-semibold text-slate-800">31</span>
          </div>
        </div>
      </div>
    </div>
  </AppLayout>
</template>


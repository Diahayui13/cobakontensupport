<script setup>
import { Head, useForm } from "@inertiajs/vue3";

const form = useForm({
  email: "",
  password: "",
  remember: true,
});

const handleLogin = () => {
  form.post("/login", {
    onFinish: () => form.reset("password"),
  });
};
</script>

<template>
  <Head title="Masuk" />

  <div class="bg-slate-100 min-h-screen flex items-center justify-center p-4 antialiased">
    <div class="max-w-md w-full bg-white rounded-xl shadow-lg border border-slate-200 p-8">
      <!-- Logo & Identitas Media -->
      <div class="text-center mb-8">
        <div class="inline-flex items-center justify-center w-14 h-14 bg-red-600 text-white font-bold text-2xl rounded-xl shadow-md mb-3">RB</div>
        <h1 class="text-2xl font-bold text-slate-800 tracking-tight">kontensupport</h1>
        <p class="text-sm text-slate-500 mt-1">Sistem Otomasi Konten Media Sosial Radar Bojonegoro</p>
      </div>

      <!-- Pesan Galat Validasi Umum / Autentikasi -->
      <div v-if="form.errors.email" class="mb-5 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm flex items-start gap-2">
        <svg class="w-5 h-5 shrink-0 text-red-500 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span>{{ form.errors.email }}</span>
      </div>

      <!-- Form Login -->
      <form @submit.prevent="handleLogin" class="space-y-5">
        <div>
          <label for="email" class="block text-sm font-semibold text-slate-700 mb-1">Alamat Email</label>
          <input
            id="email"
            v-model="form.email"
            type="email"
            required
            autocomplete="email"
            class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-colors"
            placeholder="nama@radarbojonegoro.id"
          />
        </div>

        <div>
          <label for="password" class="block text-sm font-semibold text-slate-700 mb-1">Kata Sandi</label>
          <input
            id="password"
            v-model="form.password"
            type="password"
            required
            autocomplete="current-password"
            class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-colors"
            placeholder="Masukkan kata sandi"
          />
          <p v-if="form.errors.password" class="text-xs text-red-600 mt-1">{{ form.errors.password }}</p>
        </div>

        <div class="pt-2">
          <button
            type="submit"
            :disabled="form.processing"
            class="w-full bg-red-600 hover:bg-red-700 disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold py-2.5 px-4 rounded-lg shadow-sm transition-colors duration-150 flex items-center justify-center gap-2 cursor-pointer"
          >
            <svg v-if="form.processing" class="w-4 h-4 animate-spin text-white" fill="none" viewBox="0 0 24 24">
              <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
              <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
            </svg>
            <span v-if="form.processing">Memeriksa...</span>
            <span v-else>Masuk ke Sistem</span>
            <svg v-if="!form.processing" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </button>
        </div>
      </form>

      <!-- Informasi Batasan Ruang Lingkup -->
      <div class="mt-8 pt-6 border-t border-slate-200 text-center">
        <p class="text-xs text-slate-400">Akses internal terbatas untuk Manajer Digital & Editor Naskah. Tidak tersedia registrasi mandiri.</p>
      </div>
    </div>
  </div>
</template>



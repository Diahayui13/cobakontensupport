<script setup>
import { ref, computed } from "vue";
import { Head, useForm, router, usePage } from "@inertiajs/vue3";
import AppLayout from "../../Layouts/AppLayout.vue";

const props = defineProps({
  contentTypes: {
    type: Array,
    default: () => [],
  },
});

const page = usePage();
const flashSuccess = computed(() => page.props.flash?.success);
const flashError = computed(() => page.props.flash?.error);

// State dialog modal tambah / edit
const showModal = ref(false);
const isEditing = ref(false);
const editingId = ref(null);

const form = useForm({
  name: "",
  style_rules: "",
  example: "",
});

const openCreateModal = () => {
  isEditing.value = false;
  editingId.value = null;
  form.reset();
  form.clearErrors();
  showModal.value = true;
};

const openEditModal = (ct) => {
  isEditing.value = true;
  editingId.value = ct.id;
  form.clearErrors();
  form.name = ct.name;
  form.style_rules = ct.style_rules;
  form.example = ct.example || "";
  showModal.value = true;
};

const closeModal = () => {
  showModal.value = false;
  form.reset();
  form.clearErrors();
};

const submitForm = () => {
  if (isEditing.value) {
    form.put(`/jenis-konten/${editingId.value}`, {
      onSuccess: () => closeModal(),
    });
  } else {
    form.post("/jenis-konten", {
      onSuccess: () => closeModal(),
    });
  }
};

const confirmDelete = (ct) => {
  if (ct.articles_count > 0) {
    alert("Jenis konten ini sedang digunakan oleh " + ct.articles_count + " artikel dan tidak dapat dihapus.");
    return;
  }
  if (confirm(`Apakah Anda yakin ingin menghapus jenis konten "${ct.name}"?`)) {
    router.delete(`/jenis-konten/${ct.id}`);
  }
};
</script>

<template>
  <AppLayout>
    <Head title="Manajemen Jenis Konten" />

    <div class="p-6 max-w-7xl mx-auto space-y-6">
      <!-- Header Halaman -->
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-800 tracking-tight">Manajemen Jenis Konten</h1>
          <p class="text-sm text-slate-500 mt-1">
            Konfigurasi aturan gaya bahasa penulisan untuk mengarahkan hasil caption AI per jenis liputan.
          </p>
        </div>
        <button
          type="button"
          @click="openCreateModal"
          class="inline-flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors cursor-pointer self-start sm:self-auto"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
          </svg>
          <span>Tambah Jenis Konten</span>
        </button>
      </div>

      <!-- Notifikasi Flash -->
      <div v-if="flashSuccess" class="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm flex items-center justify-between">
        <div class="flex items-center gap-2">
          <svg class="w-5 h-5 text-emerald-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
          </svg>
          <span>{{ flashSuccess }}</span>
        </div>
      </div>

      <div v-if="flashError" class="p-4 bg-red-50 border border-red-200 text-red-800 rounded-lg text-sm flex items-center justify-between">
        <div class="flex items-center gap-2">
          <svg class="w-5 h-5 text-red-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>{{ flashError }}</span>
        </div>
      </div>

      <!-- Teks Bantuan Tetap Sesuai Persyaratan Skripsi -->
      <div class="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-sm flex items-start gap-3">
        <svg class="w-5 h-5 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <div class="space-y-1">
          <p class="font-semibold text-amber-950">Catatan Penggunaan Jenis Konten:</p>
          <p class="text-xs text-amber-800 leading-relaxed">
            Tiga jenis awal adalah contoh dan perlu divalidasi editor Radar. Aturan gaya dikirim ke AI sebagai instruksi; jangan menaruh nama orang atau fakta berita di sini.
          </p>
          <p class="text-[11px] text-amber-700">
            * Kolom contoh referensi hanya berfungsi sebagai panduan internal bagi tim redaksi dan tidak ikut dikirim ke Gemini AI.
          </p>
        </div>
      </div>

      <!-- Tabel Daftar Jenis Konten -->
      <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm text-slate-700">
            <thead class="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-600 uppercase tracking-wider">
              <tr>
                <th class="px-5 py-3.5 w-48">Nama Jenis</th>
                <th class="px-5 py-3.5">Aturan Gaya (Masuk ke Prompt AI)</th>
                <th class="px-5 py-3.5">Contoh Referensi (Hanya Redaksi)</th>
                <th class="px-5 py-3.5 w-28 text-center">Artikel</th>
                <th class="px-5 py-3.5 w-32 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              <tr v-for="ct in contentTypes" :key="ct.id" class="hover:bg-slate-50/75 transition-colors">
                <td class="px-5 py-4 font-semibold text-slate-900 align-top">
                  {{ ct.name }}
                </td>
                <td class="px-5 py-4 text-xs text-slate-700 leading-relaxed align-top">
                  {{ ct.style_rules }}
                </td>
                <td class="px-5 py-4 text-xs text-slate-500 italic leading-relaxed align-top">
                  {{ ct.example || '-' }}
                </td>
                <td class="px-5 py-4 text-center align-top">
                  <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
                    {{ ct.articles_count || 0 }} artikel
                  </span>
                </td>
                <td class="px-5 py-4 text-center align-top space-x-2">
                  <button
                    type="button"
                    @click="openEditModal(ct)"
                    class="text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors cursor-pointer"
                  >
                    Sunting
                  </button>
                  <button
                    type="button"
                    @click="confirmDelete(ct)"
                    :class="[
                      'text-xs font-semibold transition-colors cursor-pointer',
                      ct.articles_count > 0 ? 'text-slate-400 hover:text-slate-500' : 'text-red-600 hover:text-red-800'
                    ]"
                    :title="ct.articles_count > 0 ? 'Tidak dapat dihapus karena digunakan artikel' : 'Hapus jenis konten'"
                  >
                    Hapus
                  </button>
                </td>
              </tr>
              <tr v-if="!contentTypes || contentTypes.length === 0">
                <td colspan="5" class="px-5 py-8 text-center text-slate-400 text-sm">
                  Belum ada jenis konten yang terdaftar.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Modal Form Tambah / Sunting -->
    <div
      v-if="showModal"
      class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs antialiased"
    >
      <div class="bg-white rounded-xl shadow-xl border border-slate-200 max-w-lg w-full p-6 space-y-5">
        <div class="flex items-center justify-between border-b border-slate-100 pb-3">
          <h2 class="text-lg font-bold text-slate-800">
            {{ isEditing ? 'Sunting Jenis Konten' : 'Tambah Jenis Konten Baru' }}
          </h2>
          <button
            type="button"
            @click="closeModal"
            class="text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form @submit.prevent="submitForm" class="space-y-4">
          <div>
            <label for="ct-name" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Nama Jenis Konten <span class="text-red-500">*</span>
            </label>
            <input
              id="ct-name"
              v-model="form.name"
              type="text"
              required
              maxlength="255"
              placeholder="Contoh: Berita Investigasi, Kolom Khusus"
              class="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
            />
            <p v-if="form.errors.name" class="text-xs text-red-600 mt-1">{{ form.errors.name }}</p>
          </div>

          <div>
            <label for="ct-rules" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Aturan Gaya Penulisan (Masuk ke AI) <span class="text-red-500">*</span>
            </label>
            <textarea
              id="ct-rules"
              v-model="form.style_rules"
              rows="4"
              required
              maxlength="1000"
              placeholder="Jelaskan karakteristik nada bahasa, fokus narasi, dan struktur kalimat yang harus dipatuhi AI..."
              class="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500 leading-relaxed"
            ></textarea>
            <div class="flex justify-between items-center mt-1">
              <p v-if="form.errors.style_rules" class="text-xs text-red-600">{{ form.errors.style_rules }}</p>
              <span class="text-[11px] text-slate-400 ml-auto">{{ form.style_rules.length }}/1000 karakter</span>
            </div>
          </div>

          <div>
            <label for="ct-example" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Contoh Teks Referensi (Hanya untuk Redaksi)
            </label>
            <textarea
              id="ct-example"
              v-model="form.example"
              rows="3"
              maxlength="2000"
              placeholder="Contoh generik sebagai rujukan redaksi internal (tidak dikirimkan ke model AI)..."
              class="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500 leading-relaxed"
            ></textarea>
            <div class="flex justify-between items-center mt-1">
              <p v-if="form.errors.example" class="text-xs text-red-600">{{ form.errors.example }}</p>
              <span class="text-[11px] text-slate-400 ml-auto">{{ form.example.length }}/2000 karakter</span>
            </div>
          </div>

          <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              @click="closeModal"
              class="px-4 py-2 border border-slate-300 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              :disabled="form.processing"
              class="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <span v-if="form.processing">Menyimpan...</span>
              <span v-else>{{ isEditing ? 'Simpan Perubahan' : 'Tambah Jenis' }}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </AppLayout>
</template>

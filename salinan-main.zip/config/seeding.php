<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Konfigurasi Akun Pengguna Seeder
    |--------------------------------------------------------------------------
    |
    | Pengaturan akun internal untuk Manajer Digital dan Editor Naskah.
    | Nilai dibaca dari variabel lingkungan (.env) agar tetap aman dan
    | dapat di-cache menggunakan perintah config:cache.
    |
    */

    'admin' => [
        'name' => env('SEEDER_ADMIN_NAME'),
        'email' => env('SEEDER_ADMIN_EMAIL'),
        'password' => env('SEEDER_ADMIN_PASSWORD'),
    ],

    'editor' => [
        'name' => env('SEEDER_EDITOR_NAME'),
        'email' => env('SEEDER_EDITOR_EMAIL'),
        'password' => env('SEEDER_EDITOR_PASSWORD'),
    ],
];

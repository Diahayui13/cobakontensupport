<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;

use App\Http\Controllers\ArticleController;
use App\Http\Controllers\AuthController;

// Rute tamu (Guest)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

// Rute aplikasi terautentikasi (Auth)
Route::middleware('auth')->group(function () {
    Route::get('/', [ArticleController::class, 'index'])->name('home');
    Route::get('/konten', [ArticleController::class, 'index'])->name('konten.index');
    Route::get('/konten/tambah', [ArticleController::class, 'create'])->name('konten.create');
    Route::get('/konten/detail', [ArticleController::class, 'create']);
    Route::get('/konten/{id}', [ArticleController::class, 'show'])->name('konten.show');
    Route::post('/konten', [ArticleController::class, 'store'])->middleware('throttle:15,1')->name('konten.store');
    Route::put('/captions/{id}', [ArticleController::class, 'updateCaption'])->name('captions.update');
    Route::post('/articles/{articleId}/regenerate', [ArticleController::class, 'regenerateAllCaptions'])->middleware('throttle:15,1')->name('articles.regenerate_all');
    Route::post('/articles/{articleId}/platforms/{platformId}/regenerate', [ArticleController::class, 'regenerateCaption'])->middleware('throttle:15,1')->name('captions.regenerate');

    Route::get('/kalender', function () {
        return Inertia::render('Kalender/Index');
    })->name('kalender.index');

    Route::get('/jenis-konten', [\App\Http\Controllers\ContentTypeController::class, 'index'])->name('jenis-konten.index');
    Route::post('/jenis-konten', [\App\Http\Controllers\ContentTypeController::class, 'store'])->name('jenis-konten.store');
    Route::put('/jenis-konten/{id}', [\App\Http\Controllers\ContentTypeController::class, 'update'])->name('jenis-konten.update');
    Route::delete('/jenis-konten/{id}', [\App\Http\Controllers\ContentTypeController::class, 'destroy'])->name('jenis-konten.destroy');

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});

/*
|--------------------------------------------------------------------------
| Health Check (HAPUS atau LINDUNGI LOGIN sebelum rilis produksi!)
|--------------------------------------------------------------------------
| Halaman diagnostik sementara untuk memverifikasi kesiapan lingkungan.
| Tidak mengekspos kunci API atau data sensitif.
*/
Route::get('/health', function () {
    // 1. Versi PHP
    $phpVersion = PHP_VERSION;

    // 2. Status koneksi database
    try {
        DB::connection()->getPdo();
        $dbStatus = 'Terhubung (' . DB::connection()->getDatabaseName() . ')';
    } catch (\Exception $e) {
        $dbStatus = 'GAGAL: ' . $e->getMessage();
    }

    // 3. Waktu terakhir scheduler (heartbeat)
    $heartbeatFile = 'heartbeat.txt';
    if (Storage::disk('local')->exists($heartbeatFile)) {
        $lastHeartbeat = Storage::disk('local')->get($heartbeatFile);
    } else {
        $lastHeartbeat = 'Belum pernah berjalan. Pastikan cron sudah aktif.';
    }

    // 4. Uji panggilan keluar ke API Gemini (hanya cek koneksi, bukan isi)
    try {
        $response = Http::timeout(10)->get('https://generativelanguage.googleapis.com');
        $outboundStatus = 'OK (HTTP ' . $response->status() . ')';
    } catch (\Exception $e) {
        $outboundStatus = 'GAGAL: ' . $e->getMessage();
    }

    // Tampilkan hasil dalam format teks sederhana
    return response(implode("\n", [
        'STATUS: OK',
        '',
        'PHP Version     : ' . $phpVersion,
        'Database        : ' . $dbStatus,
        'Scheduler       : ' . $lastHeartbeat,
        'Outbound HTTP   : ' . $outboundStatus,
        '',
        'Waktu Server    : ' . now()->timezone('Asia/Jakarta')->format('d M Y H:i:s') . ' WIB',
    ]), 200, ['Content-Type' => 'text/plain; charset=utf-8']);
})->withoutMiddleware('web');

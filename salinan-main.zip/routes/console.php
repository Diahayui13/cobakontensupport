<?php

use Illuminate\Support\Facades\Schedule;
use Illuminate\Support\Facades\Storage;

/*
|--------------------------------------------------------------------------
| Heartbeat Scheduler (tiap menit)
|--------------------------------------------------------------------------
| Menulis waktu saat ini ke storage/app/heartbeat.txt setiap menit.
| Digunakan oleh halaman /health untuk memverifikasi cron aktif.
*/
Schedule::call(function () {
    Storage::disk('local')->put(
        'heartbeat.txt',
        now()->timezone('Asia/Jakarta')->format('d M Y H:i:s') . ' WIB'
    );
})->everyMinute()->name('heartbeat');

<?php

namespace App\Exceptions;

use RuntimeException;

class AiServiceException extends RuntimeException
{
    public const TYPE_CONFIG = 'config';
    public const TYPE_QUOTA = 'quota';
    public const TYPE_AUTH = 'auth';
    public const TYPE_TIMEOUT = 'timeout';
    public const TYPE_NETWORK = 'network';
    public const TYPE_SERVER = 'server';
    public const TYPE_INVALID_JSON = 'invalid_json';
    public const TYPE_MISSING_PLATFORM = 'missing_platform';

    public string $type;

    public function __construct(string $message, string $type = self::TYPE_SERVER, int $code = 0, ?\Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
        $this->type = $type;
    }

    public function getType(): string
    {
        return $this->type;
    }
}

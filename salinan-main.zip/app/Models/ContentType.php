<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ContentType extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'style_rules',
        'example',
    ];

    /**
     * Relasi ke seluruh artikel yang menggunakan jenis konten ini.
     */
    public function articles(): HasMany
    {
        return $this->hasMany(Article::class);
    }
}

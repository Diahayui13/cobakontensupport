<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Platform extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'char_limit',
        'image_ratios',
        'style_rules',
    ];

    protected $casts = [
        'image_ratios' => 'array',
        'char_limit' => 'integer',
    ];

    public function captions(): HasMany
    {
        return $this->hasMany(Caption::class);
    }
}

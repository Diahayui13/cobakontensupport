<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Caption extends Model
{
    use HasFactory;

    protected $fillable = [
        'article_id',
        'platform_id',
        'attempt_no',
        'ai_text',
        'final_text',
        'hashtags',
        'summary',
        'status',
        'ready_at',
    ];

    protected $casts = [
        'hashtags' => 'array',
        'attempt_no' => 'integer',
        'ready_at' => 'datetime',
    ];

    public function article(): BelongsTo
    {
        return $this->belongsTo(Article::class);
    }

    public function platform(): BelongsTo
    {
        return $this->belongsTo(Platform::class);
    }
}

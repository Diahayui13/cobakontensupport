<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\AiRequest;
use App\Models\Article;
use App\Models\Caption;
use App\Models\ContentType;
use App\Models\Platform;
use App\Services\ContentGeneratorService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;

class ArticleController extends Controller
{
    /**
     * Tampilkan daftar seluruh artikel konten dari database.
     */
    public function index(): Response
    {
        $articles = Article::with(['user', 'captions.platform'])
            ->latest()
            ->get()
            ->map(function ($article) {
                $platformNames = $article->captions
                    ->pluck('platform.name')
                    ->filter()
                    ->unique()
                    ->values();

                $captions = $article->captions;
                $allSiap = $captions->isNotEmpty() && $captions->every(fn($c) => $c->status === 'siap');
                $hasTerjadwal = $captions->contains(fn($c) => $c->status === 'terjadwal');
                $hasTerbit = $captions->contains(fn($c) => $c->status === 'terbit');

                if ($hasTerbit) {
                    $status = 'terbit';
                    $statusLabel = 'Terbit';
                    $statusClass = 'bg-blue-100 text-blue-800';
                } elseif ($hasTerjadwal) {
                    $status = 'terjadwal';
                    $statusLabel = 'Terjadwal';
                    $statusClass = 'bg-amber-100 text-amber-800';
                } elseif ($allSiap) {
                    $status = 'siap';
                    $statusLabel = 'Siap Pakai';
                    $statusClass = 'bg-emerald-100 text-emerald-800';
                } else {
                    $status = 'draf';
                    $statusLabel = 'Draf (Penyuntingan)';
                    $statusClass = 'bg-slate-200 text-slate-700';
                }

                $maxAttempt = $captions->max('attempt_no') ?? 1;

                return [
                    'id' => $article->id,
                    'title' => $article->title,
                    'created_at' => $article->created_at->timezone('Asia/Jakarta')->translatedFormat('d M Y, H:i') . ' WIB',
                    'author' => $article->user->name ?? 'Editor Naskah',
                    'platforms' => $platformNames,
                    'status' => $status,
                    'status_label' => $statusLabel,
                    'status_class' => $statusClass,
                    'attempt' => '#' . $maxAttempt . ($maxAttempt > 1 ? ' (Regenerasi)' : ' (Awal)'),
                ];
            });

        return Inertia::render('Konten/Index', [
            'articles' => $articles,
        ]);
    }

    /**
     * Formulir pembuatan artikel baru.
     */
    public function create(): Response
    {
        $platforms = Platform::all();
        $contentTypes = ContentType::all(['id', 'name', 'style_rules', 'example']);

        return Inertia::render('Konten/Detail', [
            'article' => null,
            'platforms' => $platforms,
            'contentTypes' => $contentTypes,
            'captions' => [],
        ]);
    }

    /**
     * Simpan artikel baru dan panggil Gemini AI untuk membuat caption.
     */
    public function store(Request $request, ContentGeneratorService $generator)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'body' => 'required|string',
            'notes_for_ai' => 'nullable|string',
            'content_type_id' => 'nullable|exists:content_types,id',
            'target_platforms' => 'required|array|min:1',
        ], [
            'title.required' => 'Judul artikel wajib diisi.',
            'body.required' => 'Isi naskah artikel wajib diisi.',
            'content_type_id.exists' => 'Jenis konten yang dipilih tidak valid.',
            'target_platforms.required' => 'Pilih minimal satu platform media sosial tujuan.',
        ]);

        $user = $request->user();

        // 1. Simpan artikel (kolom lama content_type tidak ditulis)
        $article = Article::create([
            'user_id' => $user->id,
            'title' => $validated['title'],
            'body' => $validated['body'],
            'notes_for_ai' => $validated['notes_for_ai'] ?? null,
            'content_type_id' => $validated['content_type_id'] ?? null,
        ]);

        ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'article_created',
            'object_type' => 'Article',
            'object_id' => $article->id,
            'created_at' => now(),
        ]);

        $contentType = !empty($validated['content_type_id'])
            ? ContentType::find($validated['content_type_id'])
            : null;

        // 2. Panggil Gemini AI Generator
        $platforms = Platform::whereIn('slug', $validated['target_platforms'])->get();
        $platformLimits = $platforms->pluck('char_limit', 'slug')->toArray();

        $startTime = microtime(true);
        try {
            $aiResult = $generator->generate(
                $validated['title'],
                $validated['body'],
                $validated['notes_for_ai'] ?? null,
                $contentType?->style_rules,
                $validated['target_platforms'],
                $platformLimits
            );

            $durationMs = (int) round((microtime(true) - $startTime) * 1000);

            AiRequest::create([
                'article_id' => $article->id,
                'started_at' => now(),
                'duration_ms' => $durationMs,
                'status' => 'success',
            ]);

            // 3. Simpan caption per platform yang dipilih
            foreach ($platforms as $platform) {
                $slug = $platform->slug;
                // Petakan variasi nama kunci di respon JSON
                $key = match ($slug) {
                    'x' => isset($aiResult['x']) ? 'x' : 'twitter',
                    default => $slug,
                };

                $platformData = $aiResult[$key] ?? null;

                $captionText = '';
                $hashtags = [];
                $summary = $platformData['summary'] ?? ($aiResult['summary'] ?? null);

                if (is_array($platformData)) {
                    $captionText = $platformData['caption'] ?? '';
                    $hashtags = $platformData['hashtags'] ?? [];
                    $summary = $platformData['summary'] ?? $summary;
                } elseif (is_string($platformData)) {
                    $captionText = $platformData;
                }

                if (empty($captionText)) {
                    $captionText = $article->title . "\n\n" . mb_substr($article->body, 0, $platform->char_limit);
                }

                Caption::create([
                    'article_id' => $article->id,
                    'platform_id' => $platform->id,
                    'attempt_no' => 1,
                    'ai_text' => $captionText,
                    'final_text' => $captionText,
                    'hashtags' => $hashtags,
                    'summary' => $summary,
                    'status' => 'draf',
                ]);
            }

            ActivityLog::create([
                'user_id' => $user->id,
                'action' => 'captions_generated',
                'object_type' => 'Article',
                'object_id' => $article->id,
                'created_at' => now(),
            ]);

            return redirect()->route('konten.show', $article->id)
                ->with('success', 'Artikel dan caption AI berhasil dibuat!');
        } catch (\Exception $e) {
            $durationMs = (int) round((microtime(true) - $startTime) * 1000);

            AiRequest::create([
                'article_id' => $article->id,
                'started_at' => now(),
                'duration_ms' => $durationMs,
                'status' => 'failed',
                'error_message' => $e->getMessage(),
            ]);

            return redirect()->route('konten.show', $article->id)
                ->with('error', 'Artikel tersimpan, namun pembuatan caption AI gagal: ' . $e->getMessage());
        }
    }

    /**
     * Tampilkan detail artikel dan seluruh kartu caption platform.
     */
    public function show($id): Response
    {
        $article = Article::with(['user', 'contentType', 'captions.platform'])->findOrFail($id);
        $platforms = Platform::all();
        $contentTypes = ContentType::all(['id', 'name', 'style_rules', 'example']);

        // Kelompokkan caption aktif per platform (nomor attempt_no tertinggi)
        $latestCaptions = [];
        foreach ($platforms as $platform) {
            $activeCaption = $article->captions
                ->where('platform_id', $platform->id)
                ->sortByDesc('attempt_no')
                ->first();

            if ($activeCaption) {
                $latestCaptions[$platform->slug] = [
                    'id' => $activeCaption->id,
                    'platform_id' => $platform->id,
                    'platform_name' => $platform->name,
                    'platform_slug' => $platform->slug,
                    'attempt_no' => $activeCaption->attempt_no,
                    'ai_text' => $activeCaption->ai_text,
                    'final_text' => $activeCaption->final_text ?? $activeCaption->ai_text,
                    'status' => $activeCaption->status,
                    'limit' => $platform->char_limit,
                    'hashtags' => $activeCaption->hashtags ?? [],
                    'summary' => $activeCaption->summary,
                    'ready_at' => $activeCaption->ready_at?->toIso8601String(),
                ];
            }
        }

        return Inertia::render('Konten/Detail', [
            'article' => [
                'id' => $article->id,
                'title' => $article->title,
                'body' => $article->body,
                'notes_for_ai' => $article->notes_for_ai,
                'content_type_id' => $article->content_type_id,
                'created_at' => $article->created_at->timezone('Asia/Jakarta')->translatedFormat('d M Y, H:i') . ' WIB',
                'author' => $article->user->name ?? 'Editor Naskah',
            ],
            'platforms' => $platforms,
            'contentTypes' => $contentTypes,
            'captions' => $latestCaptions,
        ]);
    }

    /**
     * Simpan perubahan final_text atau tandai caption sebagai siap pakai.
     */
    public function updateCaption(Request $request, $id)
    {
        $validated = $request->validate([
            'final_text' => 'required|string',
            'status' => 'nullable|string|in:draf,siap',
        ]);

        $caption = Caption::findOrFail($id);
        $user = $request->user();

        $isReady = ($validated['status'] ?? null) === 'siap';

        $caption->final_text = $validated['final_text'];
        $caption->status = $isReady ? 'siap' : 'draf';
        if ($isReady) {
            $caption->ready_at = now();
        }
        $caption->save();

        ActivityLog::create([
            'user_id' => $user->id,
            'action' => $isReady ? 'caption_ready' : 'caption_edited',
            'object_type' => 'Caption',
            'object_id' => $caption->id,
            'created_at' => now(),
        ]);

        return back()->with('success', $isReady ? 'Caption siap pakai!' : 'Draf caption berhasil disimpan.');
    }

    /**
     * Buat ulang (regenerate) caption untuk satu platform tertentu.
     */
    public function regenerateCaption(Request $request, $articleId, $platformId, ContentGeneratorService $generator)
    {
        $article = Article::with('contentType')->findOrFail($articleId);
        $platform = Platform::findOrFail($platformId);
        $user = $request->user();

        $maxAttempt = Caption::where('article_id', $articleId)
            ->where('platform_id', $platformId)
            ->max('attempt_no') ?? 0;

        $newAttempt = $maxAttempt + 1;

        $notes = $article->notes_for_ai;
        if (!empty($notes)) {
            $notes .= " (Buat variasi draf baru ke-{$newAttempt} khusus untuk {$platform->name})";
        } else {
            $notes = "Buat variasi draf baru ke-{$newAttempt} khusus untuk {$platform->name}";
        }

        $platformLimits = [$platform->slug => $platform->char_limit];

        $startTime = microtime(true);
        try {
            $aiResult = $generator->generate(
                $article->title,
                $article->body,
                $notes,
                $article->contentType?->style_rules,
                [$platform->slug],
                $platformLimits
            );
            $durationMs = (int) round((microtime(true) - $startTime) * 1000);

            AiRequest::create([
                'article_id' => $article->id,
                'started_at' => now(),
                'duration_ms' => $durationMs,
                'status' => 'success',
            ]);

            $slug = $platform->slug;
            $key = match ($slug) {
                'x' => isset($aiResult['x']) ? 'x' : 'twitter',
                default => $slug,
            };

            $platformData = $aiResult[$key] ?? null;
            $captionText = '';
            $hashtags = [];
            $summary = $platformData['summary'] ?? ($aiResult['summary'] ?? null);

            if (is_array($platformData)) {
                $captionText = $platformData['caption'] ?? '';
                $hashtags = $platformData['hashtags'] ?? [];
                $summary = $platformData['summary'] ?? $summary;
            } elseif (is_string($platformData)) {
                $captionText = $platformData;
            }

            if (empty($captionText)) {
                $captionText = $article->title . "\n\n" . mb_substr($article->body, 0, $platform->char_limit);
            }

            $newCaption = Caption::create([
                'article_id' => $article->id,
                'platform_id' => $platform->id,
                'attempt_no' => $newAttempt,
                'ai_text' => $captionText,
                'final_text' => $captionText,
                'hashtags' => $hashtags,
                'summary' => $summary,
                'status' => 'draf',
            ]);

            ActivityLog::create([
                'user_id' => $user->id,
                'action' => 'caption_regenerated',
                'object_type' => 'Caption',
                'object_id' => $newCaption->id,
                'created_at' => now(),
            ]);

            return back()->with('success', "Caption untuk {$platform->name} berhasil dibuat ulang (#{$newAttempt})!");
        } catch (\Exception $e) {
            $durationMs = (int) round((microtime(true) - $startTime) * 1000);

            AiRequest::create([
                'article_id' => $article->id,
                'started_at' => now(),
                'duration_ms' => $durationMs,
                'status' => 'failed',
                'error_message' => $e->getMessage(),
            ]);

            return back()->with('error', "Gagal membuat ulang caption: " . $e->getMessage());
        }
    }

    /**
     * Buat ulang (regenerate) caption untuk seluruh platform yang dipilih pada artikel yang sudah ada.
     */
    public function regenerateAllCaptions(Request $request, $articleId, ContentGeneratorService $generator)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'body' => 'required|string',
            'notes_for_ai' => 'nullable|string',
            'content_type_id' => 'nullable|exists:content_types,id',
            'target_platforms' => 'required|array|min:1',
        ]);

        $article = Article::with('contentType')->findOrFail($articleId);
        $user = $request->user();

        // 1. Perbarui data naskah artikel jika ada perubahan dari form (tanpa menulis kolom lama content_type)
        $article->update([
            'title' => $validated['title'],
            'body' => $validated['body'],
            'notes_for_ai' => $validated['notes_for_ai'] ?? null,
            'content_type_id' => $validated['content_type_id'] ?? null,
        ]);
        $article->load('contentType');

        $platforms = Platform::whereIn('slug', $validated['target_platforms'])->get();
        $platformLimits = $platforms->pluck('char_limit', 'slug')->toArray();

        $startTime = microtime(true);
        try {
            $notes = $article->notes_for_ai;
            if (!empty($notes)) {
                $notes .= " (Buat variasi caption baru untuk seluruh platform)";
            } else {
                $notes = "Buat variasi caption baru untuk seluruh platform";
            }

            $aiResult = $generator->generate(
                $article->title,
                $article->body,
                $notes,
                $article->contentType?->style_rules,
                $validated['target_platforms'],
                $platformLimits
            );

            $durationMs = (int) round((microtime(true) - $startTime) * 1000);

            AiRequest::create([
                'article_id' => $article->id,
                'started_at' => now(),
                'duration_ms' => $durationMs,
                'status' => 'success',
            ]);

            // 2. Buat caption baru per platform dengan nomor attempt_no bertambah
            foreach ($platforms as $platform) {
                $slug = $platform->slug;
                $key = match ($slug) {
                    'x' => isset($aiResult['x']) ? 'x' : 'twitter',
                    default => $slug,
                };

                $platformData = $aiResult[$key] ?? null;
                $captionText = '';
                $hashtags = [];
                $summary = $platformData['summary'] ?? ($aiResult['summary'] ?? null);

                if (is_array($platformData)) {
                    $captionText = $platformData['caption'] ?? '';
                    $hashtags = $platformData['hashtags'] ?? [];
                    $summary = $platformData['summary'] ?? $summary;
                } elseif (is_string($platformData)) {
                    $captionText = $platformData;
                }

                if (empty($captionText)) {
                    $captionText = $article->title . "\n\n" . mb_substr($article->body, 0, $platform->char_limit);
                }

                $maxAttempt = Caption::where('article_id', $article->id)
                    ->where('platform_id', $platform->id)
                    ->max('attempt_no') ?? 0;

                $newAttempt = $maxAttempt + 1;

                $newCaption = Caption::create([
                    'article_id' => $article->id,
                    'platform_id' => $platform->id,
                    'attempt_no' => $newAttempt,
                    'ai_text' => $captionText,
                    'final_text' => $captionText,
                    'hashtags' => $hashtags,
                    'summary' => $summary,
                    'status' => 'draf',
                ]);

                ActivityLog::create([
                    'user_id' => $user->id,
                    'action' => 'caption_regenerated',
                    'object_type' => 'Caption',
                    'object_id' => $newCaption->id,
                    'created_at' => now(),
                ]);
            }

            return redirect()->route('konten.show', $article->id)
                ->with('success', 'Caption semua platform berhasil dibuat ulang!');
        } catch (\Exception $e) {
            $durationMs = (int) round((microtime(true) - $startTime) * 1000);

            AiRequest::create([
                'article_id' => $article->id,
                'started_at' => now(),
                'duration_ms' => $durationMs,
                'status' => 'failed',
                'error_message' => $e->getMessage(),
            ]);

            return redirect()->route('konten.show', $article->id)
                ->with('error', 'Gagal membuat ulang caption semua platform: ' . $e->getMessage());
        }
    }
}


<?php

namespace App\Http\Controllers;

use App\Models\ContentType;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class ContentTypeController extends Controller
{
    /**
     * Tampilkan daftar seluruh jenis konten beserta jumlah artikel terkait.
     */
    public function index(): Response
    {
        $contentTypes = ContentType::withCount('articles')
            ->latest('id')
            ->get();

        return Inertia::render('JenisKonten/Index', [
            'contentTypes' => $contentTypes,
        ]);
    }

    /**
     * Simpan jenis konten baru ke database.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:content_types,name'],
            'style_rules' => ['required', 'string', 'max:1000'],
            'example' => ['nullable', 'string', 'max:2000'],
        ], [
            'name.required' => 'Nama jenis konten wajib diisi.',
            'name.unique' => 'Nama jenis konten sudah terdaftar.',
            'name.max' => 'Nama jenis konten maksimal :max karakter.',
            'style_rules.required' => 'Aturan gaya penulisan wajib diisi.',
            'style_rules.max' => 'Aturan gaya penulisan maksimal :max karakter.',
            'example.max' => 'Contoh teks maksimal :max karakter.',
        ]);

        ContentType::create($validated);

        return redirect()->route('jenis-konten.index')
            ->with('success', 'Jenis konten berhasil ditambahkan.');
    }

    /**
     * Perbarui data jenis konten yang sudah ada.
     */
    public function update(Request $request, $id): RedirectResponse
    {
        $contentType = ContentType::findOrFail($id);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', Rule::unique('content_types', 'name')->ignore($contentType->id)],
            'style_rules' => ['required', 'string', 'max:1000'],
            'example' => ['nullable', 'string', 'max:2000'],
        ], [
            'name.required' => 'Nama jenis konten wajib diisi.',
            'name.unique' => 'Nama jenis konten sudah terdaftar.',
            'name.max' => 'Nama jenis konten maksimal :max karakter.',
            'style_rules.required' => 'Aturan gaya penulisan wajib diisi.',
            'style_rules.max' => 'Aturan gaya penulisan maksimal :max karakter.',
            'example.max' => 'Contoh teks maksimal :max karakter.',
        ]);

        $contentType->update($validated);

        return redirect()->route('jenis-konten.index')
            ->with('success', 'Jenis konten berhasil diperbarui.');
    }

    /**
     * Hapus jenis konten jika tidak sedang digunakan oleh artikel mana pun.
     */
    public function destroy($id): RedirectResponse
    {
        $contentType = ContentType::findOrFail($id);

        if ($contentType->articles()->exists()) {
            return back()->with('error', 'Jenis konten tidak dapat dihapus karena masih digunakan oleh artikel.');
        }

        $contentType->delete();

        return redirect()->route('jenis-konten.index')
            ->with('success', 'Jenis konten berhasil dihapus.');
    }
}

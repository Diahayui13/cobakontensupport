<?php

namespace Tests\Feature;

use Tests\TestCase;

class HealthCheckTest extends TestCase
{
    public function test_health_check_returns_ok_and_diagnostic_info(): void
    {
        $response = $this->get('/health');

        $response->assertStatus(200);
        $response->assertSee('STATUS: OK');
        $response->assertSee('PHP Version');
        $response->assertSee('Database');
        $response->assertSee('Scheduler');
        $response->assertSee('Outbound HTTP');
    }
}

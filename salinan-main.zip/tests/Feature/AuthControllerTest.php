<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\UserSeeder;
use Tests\TestCase;

class AuthControllerTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(UserSeeder::class);
    }

    public function test_can_view_login_page_as_guest(): void
    {
        $response = $this->get('/login');

        $response->assertStatus(200);
        $response->assertInertia(fn($page) => $page->component('Auth/Login'));
    }

    public function test_can_login_with_correct_credentials(): void
    {
        $password = env('SEEDER_EDITOR_PASSWORD', 'password');

        $response = $this->post('/login', [
            'email' => 'editor@radarbojonegoro.id',
            'password' => $password,
        ]);

        $response->assertRedirect('/konten');
        $this->assertAuthenticated();
    }

    public function test_cannot_login_with_incorrect_password(): void
    {
        $response = $this->from('/login')->post('/login', [
            'email' => 'editor@radarbojonegoro.id',
            'password' => 'wrongpassword',
        ]);

        $response->assertRedirect('/login');
        $response->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_unauthenticated_user_cannot_access_konten(): void
    {
        $response = $this->get('/konten');

        $response->assertRedirect('/login');
    }

    public function test_authenticated_user_can_logout(): void
    {
        $user = User::first();

        $response = $this->actingAs($user)->post('/logout');

        $response->assertRedirect('/login');
        $this->assertGuest();
    }

    public function test_authenticated_user_visiting_login_redirects_to_konten(): void
    {
        $user = User::first();

        $response = $this->actingAs($user)->get('/login');

        $response->assertRedirect('/konten');
    }
}

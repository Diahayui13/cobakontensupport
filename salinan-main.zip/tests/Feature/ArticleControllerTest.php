<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\Caption;
use App\Models\Platform;
use App\Models\User;
use Database\Seeders\PlatformSeeder;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class ArticleControllerTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        config(['services.gemini.api_key' => 'fake-test-key']);
        config(['services.gemini.model' => 'gemini-3.5-flash-lite']);
    }

    public function test_can_view_articles_index_with_database_data(): void
    {
        $user = User::factory()->create();
        $this->actingAs($user);
        Article::create([
            'user_id' => $user->id,
            'title' => 'Judul Berita Index',
            'body' => 'Isi berita untuk halaman index.',
            'content_type_id' => null,
        ]);

        $response = $this->actingAs($user)->get('/konten');

        $response->assertStatus(200);
        $response->assertInertia(
            fn($page) =>
                $page->component('Konten/Index')
                    ->has('articles')
        );
    }

    public function test_can_view_article_detail_page(): void
    {
        $this->seed(PlatformSeeder::class);
        $user = User::factory()->create();
        $this->actingAs($user);
        $article = Article::create([
            'user_id' => $user->id,
            'title' => 'Judul Test',
            'body' => 'Body test',
            'content_type_id' => null,
        ]);

        $response = $this->actingAs($user)->get("/konten/{$article->id}");

        $response->assertStatus(200);
        $response->assertInertia(
            fn($page) =>
                $page->component('Konten/Detail')
                    ->has('article')
                    ->has('captions')
                    ->has('platforms')
                    ->has('contentTypes')
        );
    }

    public function test_can_store_article_and_generate_captions_via_gemini(): void
    {
        $this->seed(PlatformSeeder::class);
        $user = User::factory()->create();
        $this->actingAs($user);

        $mockAiPayload = [
            'summary' => 'Ringkasan Berita Baru',
            'instagram' => ['caption' => 'Caption IG Berita Baru', 'hashtags' => ['#RadarBojonegoro']],
            'facebook' => ['caption' => 'Caption FB Berita Baru'],
            'x' => ['caption' => 'Cuitan X singkat di bawah 270 karakter.'],
            'tiktok' => ['caption' => 'Hook TikTok berita baru.'],
            'youtube' => ['caption' => 'Deskripsi video YouTube berita baru.'],
        ];

        Http::fake([
            'generativelanguage.googleapis.com/*' => Http::response([
                'candidates' => [
                    [
                        'content' => [
                            'parts' => [
                                ['text' => json_encode($mockAiPayload)],
                            ],
                        ],
                    ],
                ],
            ], 200),
        ]);

        $postData = [
            'title' => 'Pembangunan Flyover Bojonegoro Rampung',
            'body' => 'Pemerintah Kabupaten Bojonegoro mengumumkan pembangunan flyover telah rampung dan siap digunakan warga mulai pekan depan.',
            'notes_for_ai' => 'Tekankan manfaat penguraian macet.',
            'content_type_id' => null,
            'target_platforms' => ['instagram', 'x', 'facebook'],
        ];

        $response = $this->post('/konten', $postData);

        $this->assertDatabaseHas('articles', [
            'title' => 'Pembangunan Flyover Bojonegoro Rampung',
        ]);

        $createdArticle = Article::where('title', 'Pembangunan Flyover Bojonegoro Rampung')->latest('id')->first();
        $response->assertRedirect("/konten/{$createdArticle->id}");

        $this->assertDatabaseHas('captions', [
            'article_id' => $createdArticle->id,
            'status' => 'draf',
        ]);

        $this->assertDatabaseHas('activity_logs', [
            'action' => 'captions_generated',
            'object_id' => $createdArticle->id,
        ]);
    }

    public function test_can_update_caption_and_mark_as_ready(): void
    {
        $this->seed(PlatformSeeder::class);
        $user = User::factory()->create();
        $this->actingAs($user);
        $platform = Platform::where('slug', 'instagram')->first();

        $article = Article::create([
            'user_id' => $user->id,
            'title' => 'Artikel untuk Disunting',
            'body' => 'Isi teks artikel pengujian sunting caption.',
            'content_type_id' => null,
        ]);

        $caption = Caption::create([
            'article_id' => $article->id,
            'platform_id' => $platform->id,
            'attempt_no' => 1,
            'ai_text' => 'Teks awal caption buatan AI.',
            'status' => 'draf',
        ]);

        $response = $this->actingAs($user)->put("/captions/{$caption->id}", [
            'final_text' => 'Teks yang telah disunting sempurna oleh editor naskah.',
            'status' => 'siap',
        ]);

        $response->assertRedirect();

        $caption->refresh();
        $this->assertEquals('siap', $caption->status);
        $this->assertEquals('Teks yang telah disunting sempurna oleh editor naskah.', $caption->final_text);
        $this->assertNotNull($caption->ready_at);

        $this->assertDatabaseHas('activity_logs', [
            'action' => 'caption_ready',
            'object_id' => $caption->id,
        ]);
    }

    public function test_can_regenerate_single_platform_caption(): void
    {
        $this->seed(PlatformSeeder::class);
        $user = User::factory()->create();
        $this->actingAs($user);
        $platform = Platform::where('slug', 'x')->first();

        $article = Article::create([
            'user_id' => $user->id,
            'title' => 'Artikel Uji Regenerasi Single',
            'body' => 'Isi teks artikel untuk regenerasi single platform.',
            'content_type_id' => null,
        ]);

        Caption::create([
            'article_id' => $article->id,
            'platform_id' => $platform->id,
            'attempt_no' => 1,
            'status' => 'draf',
            'ai_text' => 'Teks cuitan X awal.',
        ]);

        $initialMaxAttempt = Caption::where('article_id', $article->id)
            ->where('platform_id', $platform->id)
            ->max('attempt_no') ?? 0;

        $mockAiPayload = [
            'x' => ['caption' => 'Variasi cuitan kedua untuk X yang baru dibuatkan Gemini.'],
        ];

        Http::fake([
            'generativelanguage.googleapis.com/*' => Http::response([
                'candidates' => [
                    [
                        'content' => [
                            'parts' => [
                                ['text' => json_encode($mockAiPayload)],
                            ],
                        ],
                    ],
                ],
            ], 200),
        ]);

        $response = $this->actingAs($user)->post("/articles/{$article->id}/platforms/{$platform->id}/regenerate");

        $response->assertRedirect();

        $this->assertDatabaseHas('captions', [
            'article_id' => $article->id,
            'platform_id' => $platform->id,
            'attempt_no' => $initialMaxAttempt + 1,
            'status' => 'draf',
        ]);

        $this->assertDatabaseHas('activity_logs', [
            'action' => 'caption_regenerated',
        ]);
    }

    public function test_can_regenerate_all_platforms_for_existing_article(): void
    {
        $this->seed(PlatformSeeder::class);
        $user = User::factory()->create();
        $this->actingAs($user);

        $article = Article::create([
            'user_id' => $user->id,
            'title' => 'Artikel Uji Regenerasi Semua',
            'body' => 'Isi teks artikel sebelum regenerasi total.',
            'content_type_id' => null,
        ]);

        $initialArticleCount = Article::count();

        $mockAiPayload = [
            'summary' => 'Ringkasan Berita Regenerasi Total',
            'instagram' => ['caption' => 'Caption IG Baru dari Buat Ulang Semua'],
            'facebook' => ['caption' => 'Caption FB Baru dari Buat Ulang Semua'],
        ];

        Http::fake([
            'generativelanguage.googleapis.com/*' => Http::response([
                'candidates' => [
                    [
                        'content' => [
                            'parts' => [
                                ['text' => json_encode($mockAiPayload)],
                            ],
                        ],
                    ],
                ],
            ], 200),
        ]);

        $payload = [
            'title' => $article->title . ' (Revisi)',
            'body' => $article->body . ' Tambahan informasi terkini.',
            'notes_for_ai' => 'Fokus pada update terbaru.',
            'content_type_id' => null,
            'target_platforms' => ['instagram', 'facebook'],
        ];

        $response = $this->actingAs($user)->post("/articles/{$article->id}/regenerate", $payload);

        $response->assertRedirect("/konten/{$article->id}");

        // Memastikan TIDAK membuat baris artikel baru di tabel articles
        $this->assertEquals($initialArticleCount, Article::count());

        // Memastikan artikel yang sama diperbarui
        $article->refresh();
        $this->assertStringContainsString('(Revisi)', $article->title);

        // Memastikan dibuatkan caption baru berstatus draf
        $this->assertDatabaseHas('captions', [
            'article_id' => $article->id,
            'status' => 'draf',
            'ai_text' => 'Caption IG Baru dari Buat Ulang Semua',
        ]);

        $this->assertDatabaseHas('activity_logs', [
            'action' => 'caption_regenerated',
            'object_type' => 'Caption',
        ]);
    }
}


<?php

namespace Tests\Feature;

use App\Models\Article;
use App\Models\ContentType;
use App\Models\User;
use App\Services\ContentGeneratorService;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class ContentTypeTest extends TestCase
{
    public function test_guest_cannot_access_content_type_routes(): void
    {
        $this->get('/jenis-konten')->assertRedirect('/login');
        $this->post('/jenis-konten', ['name' => 'Test'])->assertRedirect('/login');
        $this->put('/jenis-konten/1', ['name' => 'Test'])->assertRedirect('/login');
        $this->delete('/jenis-konten/1')->assertRedirect('/login');
    }

    public function test_authenticated_user_can_view_content_types_index(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->get('/jenis-konten');

        $response->assertStatus(200);
        $response->assertInertia(
            fn ($page) => $page->component('JenisKonten/Index')
                ->has('contentTypes')
        );

        // Migrasi awal telah memuat 3 jenis konten contoh
        $this->assertDatabaseHas('content_types', ['name' => 'Berita Lugas']);
        $this->assertDatabaseHas('content_types', ['name' => 'Breaking News']);
        $this->assertDatabaseHas('content_types', ['name' => 'Feature']);
    }

    public function test_authenticated_user_can_create_content_type(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->post('/jenis-konten', [
            'name' => 'Laporan Khusus Investigasi',
            'style_rules' => 'Fokus pada temuan mendalam, data investigasi, dan kronologi terperinci.',
            'example' => 'Laporan investigasi mengenai tata kelola air bersih di wilayah perdesaan.',
        ]);

        $response->assertRedirect(route('jenis-konten.index'));
        $response->assertSessionHas('success', 'Jenis konten berhasil ditambahkan.');

        $this->assertDatabaseHas('content_types', [
            'name' => 'Laporan Khusus Investigasi',
        ]);
    }

    public function test_content_type_validation_rules(): void
    {
        $user = User::factory()->create();

        // 1. Validasi field wajib
        $response = $this->actingAs($user)->from('/jenis-konten')->post('/jenis-konten', [
            'name' => '',
            'style_rules' => '',
        ]);

        $response->assertRedirect('/jenis-konten');
        $response->assertSessionHasErrors(['name', 'style_rules']);

        // 2. Validasi nama unik (Berita Lugas sudah ada dari migrasi awal)
        $uniqueResponse = $this->actingAs($user)->from('/jenis-konten')->post('/jenis-konten', [
            'name' => 'Berita Lugas',
            'style_rules' => 'Aturan gaya duplikat.',
        ]);

        $uniqueResponse->assertRedirect('/jenis-konten');
        $uniqueResponse->assertSessionHasErrors('name');
    }

    public function test_authenticated_user_can_update_content_type(): void
    {
        $user = User::factory()->create();
        $contentType = ContentType::where('name', 'Berita Lugas')->firstOrFail();

        $response = $this->actingAs($user)->put("/jenis-konten/{$contentType->id}", [
            'name' => 'Berita Lugas (Revisi)',
            'style_rules' => 'Aturan gaya baru yang disempurnakan redaktur.',
            'example' => 'Contoh teks berita lugas baru.',
        ]);

        $response->assertRedirect(route('jenis-konten.index'));
        $response->assertSessionHas('success', 'Jenis konten berhasil diperbarui.');

        $this->assertDatabaseHas('content_types', [
            'id' => $contentType->id,
            'name' => 'Berita Lugas (Revisi)',
            'style_rules' => 'Aturan gaya baru yang disempurnakan redaktur.',
        ]);
    }

    public function test_authenticated_user_can_delete_unused_content_type(): void
    {
        $user = User::factory()->create();
        $contentType = ContentType::create([
            'name' => 'Jenis Sementara',
            'style_rules' => 'Aturan sementara.',
        ]);

        $response = $this->actingAs($user)->delete("/jenis-konten/{$contentType->id}");

        $response->assertRedirect(route('jenis-konten.index'));
        $response->assertSessionHas('success', 'Jenis konten berhasil dihapus.');

        $this->assertDatabaseMissing('content_types', [
            'id' => $contentType->id,
        ]);
    }

    public function test_cannot_delete_content_type_used_by_articles(): void
    {
        $user = User::factory()->create();
        $contentType = ContentType::where('name', 'Breaking News')->firstOrFail();

        Article::create([
            'user_id' => $user->id,
            'title' => 'Artikel Breaking News Aktif',
            'body' => 'Isi artikel peristiwa terkini.',
            'content_type_id' => $contentType->id,
        ]);

        $response = $this->actingAs($user)->from('/jenis-konten')->delete("/jenis-konten/{$contentType->id}");

        $response->assertRedirect('/jenis-konten');
        $response->assertSessionHas('error', 'Jenis konten tidak dapat dihapus karena masih digunakan oleh artikel.');

        // Memastikan jenis konten tetap ada di database
        $this->assertDatabaseHas('content_types', [
            'id' => $contentType->id,
        ]);
    }

    public function test_content_generator_service_includes_style_rules_and_excludes_example(): void
    {
        config(['services.gemini.api_key' => 'dummy-api-key']);
        config(['services.gemini.model' => 'gemini-3.5-flash-lite']);

        $contentType = ContentType::where('name', 'Feature')->firstOrFail();

        Http::fake([
            'generativelanguage.googleapis.com/*' => Http::response([
                'candidates' => [
                    [
                        'content' => [
                            'parts' => [
                                ['text' => json_encode([
                                    'instagram' => ['caption' => 'Caption IG Feature', 'summary' => 'Ringkasan Feature'],
                                ])],
                            ],
                        ],
                    ],
                ],
            ], 200),
        ]);

        $service = app(ContentGeneratorService::class);
        $result = $service->generate(
            'Judul Kisah Inspiratif',
            'Isi berita tentang perjuangan narasumber.',
            'Fokus pada detail humanis.',
            $contentType->style_rules,
            ['instagram']
        );

        $this->assertIsArray($result);
        $this->assertEquals('Caption IG Feature', $result['instagram']['caption']);

        // Verifikasi bahwa permintaan HTTP yang dikirimkan ke AI memuat style_rules dan TIDAK memuat example
        Http::assertSent(function ($request) use ($contentType) {
            $data = $request->data();
            $systemContent = $data['system_instruction']['parts'][0]['text'] ?? '';

            $hasStyleRules = str_contains($systemContent, 'Aturan gaya jenis konten:')
                && str_contains($systemContent, $contentType->style_rules);

            $hasExample = !empty($contentType->example) && str_contains($systemContent, $contentType->example);

            return $hasStyleRules && !$hasExample;
        });
    }

    public function test_content_generator_service_works_without_style_rules(): void
    {
        config(['services.gemini.api_key' => 'dummy-api-key']);
        config(['services.gemini.model' => 'gemini-3.5-flash-lite']);

        Http::fake([
            'generativelanguage.googleapis.com/*' => Http::response([
                'candidates' => [
                    [
                        'content' => [
                            'parts' => [
                                ['text' => json_encode([
                                    'instagram' => ['caption' => 'Caption Standar', 'summary' => 'Ringkasan Standar'],
                                ])],
                            ],
                        ],
                    ],
                ],
            ], 200),
        ]);

        $service = app(ContentGeneratorService::class);
        $result = $service->generate(
            'Judul Berita Standar',
            'Isi berita reguler.',
            null,
            null,
            ['instagram']
        );

        $this->assertIsArray($result);
        $this->assertEquals('Caption Standar', $result['instagram']['caption']);

        // Verifikasi tidak ada blok "Aturan gaya jenis konten:" jika styleRules null
        Http::assertSent(function ($request) {
            $data = $request->data();
            $systemContent = $data['system_instruction']['parts'][0]['text'] ?? '';

            return !str_contains($systemContent, 'Aturan gaya jenis konten:');
        });
    }
}

<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\UserSeeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Tests\TestCase;

class AuthTest extends TestCase
{
    public function test_login_screen_can_be_rendered(): void
    {
        $response = $this->get('/login');

        $response->assertStatus(200);
        $response->assertInertia(
            fn ($page) => $page->component('Auth/Login')
        );
    }

    public function test_unauthenticated_user_cannot_access_protected_routes(): void
    {
        $protectedRoutes = [
            '/',
            '/konten',
            '/konten/tambah',
            '/kalender',
        ];

        foreach ($protectedRoutes as $route) {
            $response = $this->get($route);
            $response->assertRedirect('/login');
        }
    }

    public function test_user_can_login_with_valid_credentials(): void
    {
        $user = User::factory()->create([
            'email' => 'editor.valid@radarbojonegoro.id',
            'password' => Hash::make('password_rahasia'),
        ]);

        $response = $this->post('/login', [
            'email' => 'editor.valid@radarbojonegoro.id',
            'password' => 'password_rahasia',
        ]);

        $response->assertRedirect(route('konten.index'));
        $this->assertAuthenticatedAs($user);
    }

    public function test_user_cannot_login_with_invalid_credentials(): void
    {
        User::factory()->create([
            'email' => 'editor.valid@radarbojonegoro.id',
            'password' => Hash::make('password_rahasia'),
        ]);

        $response = $this->from('/login')->post('/login', [
            'email' => 'editor.valid@radarbojonegoro.id',
            'password' => 'password_salah',
        ]);

        $response->assertRedirect('/login');
        $response->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_login_validation_requires_email_and_password(): void
    {
        $response = $this->from('/login')->post('/login', [
            'email' => '',
            'password' => '',
        ]);

        $response->assertRedirect('/login');
        $response->assertSessionHasErrors(['email', 'password']);
    }

    public function test_login_throttling_after_too_many_failed_attempts(): void
    {
        RateLimiter::clear('spammer@radarbojonegoro.id|127.0.0.1');

        for ($i = 0; $i < 5; $i++) {
            $this->post('/login', [
                'email' => 'spammer@radarbojonegoro.id',
                'password' => 'salah',
            ]);
        }

        // Percobaan ke-6 harus di-throttle
        $response = $this->post('/login', [
            'email' => 'spammer@radarbojonegoro.id',
            'password' => 'salah',
        ]);

        $response->assertSessionHasErrors('email');
        $errors = session('errors')->get('email');
        $this->assertStringContainsString('Terlalu banyak percobaan masuk', $errors[0]);
    }

    public function test_user_can_logout(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->post('/logout');

        $response->assertRedirect('/login');
        $this->assertGuest();
    }

    public function test_disallowed_routes_return_404(): void
    {
        $disallowedRoutes = [
            '/register',
            '/forgot-password',
            '/profile',
        ];

        foreach ($disallowedRoutes as $route) {
            $this->get($route)->assertNotFound();
        }
    }

    public function test_user_seeder_throws_exception_if_config_is_empty(): void
    {
        config([
            'seeding.admin' => [
                'name' => '',
                'email' => '',
                'password' => '',
            ],
            'seeding.editor' => [
                'name' => '',
                'email' => '',
                'password' => '',
            ],
        ]);

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Konfigurasi akun seeder tidak lengkap');

        $seeder = new UserSeeder();
        $seeder->run();
    }

    public function test_inertia_shared_props_only_exposes_safe_user_fields(): void
    {
        $user = User::factory()->create([
            'name' => 'Editor Aman',
            'email' => 'aman@radarbojonegoro.id',
            'password' => Hash::make('password_sangat_rahasia'),
            'remember_token' => 'token_rahasia_123',
        ]);

        $response = $this->actingAs($user)->get('/konten');

        $response->assertStatus(200);
        $response->assertInertia(function ($page) use ($user) {
            $authData = $page->toArray()['props']['auth']['user'];

            $this->assertNotNull($authData);
            $this->assertEquals($user->id, $authData['id']);
            $this->assertEquals('Editor Aman', $authData['name']);
            $this->assertEquals('aman@radarbojonegoro.id', $authData['email']);

            $this->assertArrayNotHasKey('password', $authData);
            $this->assertArrayNotHasKey('remember_token', $authData);
        });
    }
}

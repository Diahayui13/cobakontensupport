<?php

namespace Tests\Feature;

use App\Models\Platform;
use App\Models\User;
use App\Models\Article;
use App\Models\Caption;
use App\Models\AiRequest;
use App\Models\ActivityLog;
use Database\Seeders\PlatformSeeder;
use Database\Seeders\UserSeeder;
use Tests\TestCase;

class DatabaseSchemaTest extends TestCase
{
    public function test_platforms_are_seeded(): void
    {
        $this->seed(PlatformSeeder::class);

        $this->assertDatabaseCount('platforms', 5);
        $this->assertDatabaseHas('platforms', ['slug' => 'instagram', 'char_limit' => 2200]);
        $this->assertDatabaseHas('platforms', ['slug' => 'x', 'char_limit' => 280]);
        $this->assertDatabaseHas('platforms', ['slug' => 'facebook', 'char_limit' => 63206]);
        $this->assertDatabaseHas('platforms', ['slug' => 'tiktok', 'char_limit' => 2200]);
        $this->assertDatabaseHas('platforms', ['slug' => 'youtube', 'char_limit' => 5000]);
    }

    public function test_users_are_seeded(): void
    {
        config([
            'seeding.admin' => [
                'name' => 'Test Manajer Digital',
                'email' => 'test.manager@radarbojonegoro.id',
                'password' => 'secret_admin_pass',
            ],
            'seeding.editor' => [
                'name' => 'Test Editor Naskah',
                'email' => 'test.editor@radarbojonegoro.id',
                'password' => 'secret_editor_pass',
            ],
        ]);

        $this->seed(UserSeeder::class);

        $this->assertDatabaseCount('users', 2);
        $this->assertDatabaseHas('users', [
            'email' => 'test.manager@radarbojonegoro.id',
            'name' => 'Test Manajer Digital',
        ]);
        $this->assertDatabaseHas('users', [
            'email' => 'test.editor@radarbojonegoro.id',
            'name' => 'Test Editor Naskah',
        ]);
    }

    public function test_article_and_caption_lifecycle_relations(): void
    {
        $user = User::factory()->create();
        $this->seed(PlatformSeeder::class);
        $platform = Platform::where('slug', 'instagram')->first();

        $article = Article::create([
            'user_id' => $user->id,
            'title' => 'Uji Coba Berita Radar',
            'body' => 'Isi teks berita pengujian untuk verifikasi skema database.',
            'notes_for_ai' => 'Tekankan keakuratan data.',
            'content_type' => 'hard_news',
        ]);

        $caption = Caption::create([
            'article_id' => $article->id,
            'platform_id' => $platform->id,
            'attempt_no' => 1,
            'ai_text' => 'Teks caption asli buatan Gemini AI.',
            'final_text' => 'Teks caption yang sudah disunting editor.',
            'hashtags' => ['#RadarBojonegoro', '#Bojonegoro'],
            'summary' => 'Ringkasan berita singkat.',
            'status' => 'siap',
            'ready_at' => now(),
        ]);

        $aiRequest = AiRequest::create([
            'article_id' => $article->id,
            'started_at' => now(),
            'duration_ms' => 1250,
            'status' => 'success',
        ]);

        $activityLog = ActivityLog::create([
            'user_id' => $user->id,
            'action' => 'captions_generated',
            'object_type' => 'Article',
            'object_id' => $article->id,
        ]);

        $this->assertDatabaseHas('articles', ['id' => $article->id, 'title' => 'Uji Coba Berita Radar']);
        $this->assertDatabaseHas('captions', ['id' => $caption->id, 'status' => 'siap']);
        $this->assertDatabaseHas('ai_requests', ['id' => $aiRequest->id, 'status' => 'success']);
        $this->assertDatabaseHas('activity_logs', ['id' => $activityLog->id, 'action' => 'captions_generated']);

        // Uji relasi Eloquent
        $this->assertEquals($article->id, $caption->article->id);
        $this->assertEquals($platform->id, $caption->platform->id);
        $this->assertEquals(1, $article->captions()->count());
        $this->assertEquals(1, $article->aiRequests()->count());
    }
}

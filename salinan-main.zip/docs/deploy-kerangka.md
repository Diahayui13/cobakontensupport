# Panduan Deploy Kerangka Aplikasi ke Hosting (untuk Pemula)

Dokumen ini berisi panduan langkah demi langkah untuk mengunggah dan menjalankan kerangka aplikasi **kontensupport** di server hosting (cPanel / Shared Hosting / VPS).

---

## 1. Persyaratan Server Hosting

Sebelum mengunggah, pastikan penyedia hosting Anda memenuhi kriteria berikut:
- **PHP versi 8.2 atau 8.3** (disarankan PHP 8.3 sesuai lingkungan pengembangan).
- Ekstensi PHP aktif: `BCMath`, `Ctype`, `cURL`, `DOM`, `Fileinfo`, `JSON`, `Mbstring`, `OpenSSL`, `PCRE`, `PDO`, `PDO_MySQL`, `Tokenizer`, `XML`.
- Database MySQL atau MariaDB.
- Akses fitur **Cron Jobs** (penjadwal tugas otomatis per menit).
- Izin koneksi internet keluar (outbound HTTP) untuk memanggil API Gemini.

---

## 2. Menyiapkan File Aplikasi

1. Kompres seluruh file proyek (kecuali folder `node_modules`, `vendor`, dan file `.env`) menjadi arsip `.zip`.
2. Unggah file `.zip` ke direktori hosting Anda (misalnya di folder `/home/username/kontensupport`).
3. Ekstrak file zip tersebut di hosting.
4. Jalankan perintah instalasi pustaka jika memiliki akses terminal/SSH:
   ```bash
   composer install --no-dev --optimize-autoloader
   ```
   *(Jika di shared hosting tanpa SSH, Anda dapat menyertakan folder `vendor` yang sudah dibuat di komputer lokal).*

---

## 3. Mengatur Dokumen Root ke Folder `public`

Laravel mewajibkan folder `public/` sebagai satu-satunya folder yang dapat diakses langsung oleh peramban (browser). Folder inti sistem lainnya tidak boleh terbuka untuk umum demi keamanan.

### Cara A: Pada cPanel / Shared Hosting
1. Buka menu **Domains** atau **Subdomains** di cPanel.
2. Ubah **Document Root** domain Anda mengarah ke:
   ```text
   /home/username/kontensupport/public
   ```
3. Simpan perubahan.

### Cara B: Pada Server VPS (Nginx / Apache)
- **Nginx:** Arahkan direktif `root` ke:
  ```nginx
  root /var/www/kontensupport/public;
  ```
- **Apache:** Arahkan direktif `DocumentRoot` ke:
  ```apache
  DocumentRoot /var/www/kontensupport/public
  ```

---

## 4. Konfigurasi File `.env` Produksi

1. Salin file `.env.example` menjadi `.env` di direktori proyek hosting.
2. Buka dan sesuaikan baris-baris konfigurasi berikut:
   ```env
   APP_NAME=kontensupport
   APP_ENV=production
   APP_DEBUG=false
   APP_URL=https://nama-domain-anda.com

   # Konfigurasi Database Hosting
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=nama_database_hosting
   DB_USERNAME=user_database_hosting
   DB_PASSWORD=password_database_hosting

   # Driver Sesi & Cache
   SESSION_DRIVER=database
   FILESYSTEM_DISK=local

   # Kunci Gemini AI (diisi saat iterasi AI dimulai)
   GEMINI_API_KEY=kunci_rahasia_anda
   GEMINI_MODEL=gemini-1.5-flash
   ```
3. **PENTING:** Pastikan `APP_DEBUG=false` agar pesan galat teknis tidak bocor ke publik saat terjadi kesalahan sistem.
4. Buat Application Key jika belum ada:
   ```bash
   php artisan key:generate
   ```

---

## 5. Menjalankan Migrasi Database

Jalankan perintah migrasi untuk membuat tabel-tabel sistem di database:
```bash
php artisan migrate --force
```
*(Parameter `--force` diperlukan karena aplikasi berada di lingkungan `production`).*

---

## 6. Memasang Cron Job Scheduler

Laravel menggunakan satu jadwal cron pusat untuk menjalankan semua tugas terjadwal (seperti heartbeat dan penjadwalan konten).

1. Buka menu **Cron Jobs** di cPanel hosting.
2. Pilih jadwal: **Every Minute (Tiap Menit)** atau masukkan pola bintang:
   ```text
   * * * * *
   ```
3. Masukkan perintah berikut (sesuaikan path folder hosting Anda):
   ```bash
   * * * * * cd /home/username/kontensupport && php artisan schedule:run >> /dev/null 2>&1
   ```
4. Klik **Add New Cron Job**.

---

## 7. Verifikasi Menggunakan Halaman `/health`

Setelah semua langkah selesai, buka peramban dan akses alamat:
```text
https://nama-domain-anda.com/health
```

Periksa hasil teks yang muncul di layar:
1. **STATUS: OK** — Menandakan rute web berhasil diproses.
2. **PHP Version** — Harus PHP 8.2 atau 8.3.
3. **Database** — Harus bertuliskan `Terhubung (nama_database)`.
4. **Scheduler** — Menampilkan waktu menit terakhir scheduler berjalan (menandakan cron job berhasil).
5. **Outbound HTTP** — Harus bertuliskan `OK (HTTP ...)`, menandakan hosting tidak memblokir akses ke API Gemini.

---

## 8. Peringatan Keamanan Sebelum Rilis Final

> **PERINGATAN PENTING:**  
> Rute `/health` adalah alat diagnostik sementara untuk memeriksa kesiapan hosting.  
> **Sebelum rilis final aplikasi, rute `/health` di file `routes/web.php` WAJIB DIHAPUS atau DILINDUNGI dengan autentikasi login** agar informasi diagnostik server tidak dapat dibaca oleh publik yang tidak berwenang.

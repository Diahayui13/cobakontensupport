# Dokumen Analisis Kebutuhan Sistem (kontensupport)

Dokumen ini disusun berdasarkan hasil wawancara tim digital Radar Bojonegoro (kode rujukan wawancara: `[A2]`, `[B1]`, `[B2]`, `[B3]`, `[D2]`, `[D4]`, `[E4]`, `[F1]`, `[F2]`, `[F3]`, `[H1]`, `[H2]`) dan ruang lingkup proyek pada AGENTS.md.

---

## 1. Daftar Kebutuhan Fungsional dan Non-Fungsional

### A. Kebutuhan Fungsional (KF)
1. **KF-01: Autentikasi Pengguna Tunggal Tingkat Akses**  
   Sistem menyediakan fungsi masuk (login) akun untuk staf tim digital (Manajer Digital dan Editor) tanpa registrasi mandiri, dengan hak akses yang setara untuk seluruh fitur.  
   *Rujukan Wawancara:* `[E4]` (Akses pengelolaan terbatas pada staf tertentu; ASUMSI: hak akses disederhanakan menjadi satu tingkat akses setara tanpa sistem peran hierarkis untuk mempercepat alur kerja).
2. **KF-02: Input Artikel Berita Terbit**  
   Sistem menyediakan antarmuka bagi pengguna untuk memasukkan artikel yang telah terbit di web (judul, isi artikel, pilihan platform tujuan, jenis konten, serta catatan instruksi tambahan).  
   *Rujukan Wawancara:* `[A2]`, `[H2]` (Artikel yang sudah terbit di web diproses menjadi bahan media sosial; ASUMSI: input dilakukan dengan menempel teks naskah secara manual ke sistem).
3. **KF-03: Peringkasan dan Pembuatan Caption Berbasis AI Sesuai Karakteristik Platform**  
   Sistem secara otomatis menghasilkan draf caption, ringkasan, dan rekomendasi tagar menggunakan kecerdasan buatan (Gemini AI) yang gayanya disesuaikan per platform (misalnya: estetika visual untuk Instagram, ringkas-interaktif untuk X).  
   *Rujukan Wawancara:* `[D2]`, `[D4]`, `[F1]`, `[F3]`.
4. **KF-04: Penyuntingan dan Pembuatan Ulang (Regenerasi) Caption**  
   Sistem menyediakan antarmuka penyuntingan caption hasil AI, penghitung batas karakter per platform, serta tombol pembuatan ulang draf (regenerasi) per platform tanpa menimpa riwayat draf sebelumnya.  
   *Rujukan Wawancara:* `[D2]`, `[F1]`, `[F3]` (Pemeriksaan manusia tetap diperlukan untuk kurasi redaksional dan kepatuhan format).
5. **KF-05: Penetapan Status Siap Pakai**  
   Sistem menyediakan aksi "Siap Pakai" untuk mengunci teks final yang siap didistribusikan dan menyalinnya ke papan klip (*clipboard*).  
   *Rujukan Wawancara:* `[A2]`, `[D2]`, `[H1]` (Menghilangkan hambatan manual sebelum naskah diunggah).
6. **KF-06: Pembuatan Aset Visual Berbasis Template Ukuran Rasio**  
   Sistem menyediakan alat olah gambar dalam peramban (*browser Canvas*) untuk mengatur posisi foto (zoom dan geser) serta menerapkan template teks berita dengan variasi rasio standar media sosial (1:1, 16:9, 9:16, 4:5) hingga ekspor file PNG.  
   *Rujukan Wawancara:* `[B2]`, `[B3]`, `[D2]`, `[F3]`.
7. **KF-07: Penjadwalan Konten Terpadu (Kalender Bulanan)**  
   Sistem menyediakan fitur pencatatan tanggal dan waktu rencana posting per platform yang divisualisasikan dalam bentuk kalender bulanan.  
   *Rujukan Wawancara:* `[D4]`, `[F2]`.
8. **KF-08: Penandaan Terbit (Mark as Published)**  
   Sistem menyediakan tombol untuk mengubah status konten menjadi "terbit" setelah pengguna selesai mengunggah naskah dan gambar ke platform terkait.  
   *Rujukan Wawancara:* `[A2]`, `[F2]`.

### B. Kebutuhan Non-Fungsional (KNF)
1. **KNF-01: Kecepatan Proses (Efisiensi Waktu Alur Kerja)**  
   Sistem harus memangkas waktu adaptasi artikel menjadi bahan siap unggah (caption dan visual) sehingga mendukung target distribusi breaking news (<15 menit) dan reguler (di bawah 1 jam).  
   *Rujukan Wawancara:* `[B1]`, `[B2]`, `[H1]`.
2. **KNF-02: Kemudahan Penggunaan dan Penghilangan Bottleneck**  
   Antarmuka sistem harus lugas, berbahasa Indonesia, dan tidak menambah birokrasi persetujuan (*approval*) yang memperlambat publikasi.  
   *Rujukan Wawancara:* `[B3]`, `[H1]`.
3. **KNF-03: Keamanan Kredensial dan Kepatuhan Kuota API**  
   Kunci API (AI Gemini) disimpan secara aman di backend/lingkungan server tanpa diekspos ke peramban, serta memiliki penanganan galat jika kuota atau koneksi terganggu.  
   *Rujukan Wawancara:* `[D4]` (ASUMSI: stabilitas integrasi sistem bergantung pada keandalan pemanggilan API backend).
4. **KNF-04: Ringan dan Kompatibel Tanpa Beban Server Tambahan**  
   Pengolahan gambar dilakukan di sisi peramban klien (*browser-based*) untuk menghemat sumber daya server hosting.  
   *Rujukan Wawancara:* `[B2]`, `[F3]` (ASUMSI: pemrosesan visual lokal di peramban menghindari latensi pengunggahan file besar bolak-balik ke server).

---

## 2. Alur Kerja: Kondisi Saat Ini vs. Alur Usulan

### A. Alur Kerja Kondisi Saat Ini (Berdasarkan `[A2]`, `[B2]`, `[D2]`, `[F2]`, `[F3]`)
1. **Reporter:** Menulis draf berita di CMS web.
2. **Editor Web:** Memeriksa fakta, kaidah bahasa, dan optimasi SEO naskah.
3. **Editor Web:** Menerbitkan artikel ke situs web resmi (memakan waktu 15–30 menit dari draf).
4. **Editor / Reporter:** Mengirimkan tautan artikel yang sudah terbit kepada Tim Media Sosial.
5. **Tim Media Sosial:** Membaca ulang artikel panjang lalu merangkum dan mengetik ulang caption secara manual sesuai gaya tiap platform (`[F1]`, `[F3]`).
6. **Tim Media Sosial:** Membuka aplikasi desain grafis eksternal, mencari stok foto, lalu mengatur ulang ukuran gambar satu per satu ke rasio 1:1, 16:9, dan 9:16 (`[B3]`, `[F3]`). (Bottleneck: memakan waktu 1–2 jam).
7. **Tim Media Sosial:** Menjadwalkan posting Instagram dan Facebook melalui Meta Business Suite (`[F2]`).
8. **Tim Media Sosial:** Menunggu atau melakukan posting manual satu per satu untuk platform lainnya (X, TikTok, YouTube) (`[F2]`).

### B. Alur Kerja Usulan (Dengan Sistem `kontensupport`)
1. **Reporter & Editor Web:** Menulis, menyunting, dan menerbitkan berita di CMS web seperti biasa.
2. **Editor / Manajer Digital:** Membuka sistem `kontensupport`, masuk menggunakan akun yang tersedia (`KF-01`).
3. **Editor / Manajer Digital:** Menempelkan judul dan naskah artikel yang sudah terbit di web ke form input, memilih target platform serta gaya jenis konten (`KF-02`).
4. **Editor / Manajer Digital:** Menekan tombol "Buat Caption"; sistem memproses ringkasan, saran tagar, dan variasi caption per platform secara otomatis menggunakan AI (`KF-03`).
5. **Editor / Manajer Digital:** Memeriksa/menyunting teks hasil AI dan menekan tombol "Siap Pakai" untuk menyalin teks final (`KF-04`, `KF-05`).
6. **Editor / Manajer Digital:** Membuka tab template visual, mengunggah foto, memilih rasio yang dibutuhkan (1:1, 16:9, 9:16, 4:5), mengatur posisi foto, dan langsung mengunduh hasil gambar PNG siap pakai (`KF-06`).
7. **Editor / Manajer Digital:** Menetapkan tanggal dan jam rencana tayang di kalender jadwal terpadu (`KF-07`).
8. **Editor / Manajer Digital:** Mengunggah konten ke platform tujuan, lalu menekan "Tandai Terbit" di sistem untuk pembaruan status arsip (`KF-08`).

---

## 3. Daftar Use Case (Satu Jenis Pengguna)

Sistem menggunakan model aktor tunggal: **Pengguna Tim Digital** (mencakup Editor dan Manajer Digital dengan hak akses setara).

| ID Use Case | Nama Use Case | Deskripsi Singkat | Aktor |
| :--- | :--- | :--- | :--- |
| **UC-01** | **Login** | Pengguna memasukkan email dan kata sandi untuk masuk ke dalam aplikasi. | Pengguna Tim Digital |
| **UC-02** | **Input Artikel** | Pengguna menempelkan judul, isi naskah artikel web, catatan opsional, serta memilih platform tujuan. | Pengguna Tim Digital |
| **UC-03** | **Buat Caption** | Pengguna memicu AI untuk menghasilkan caption otomatis, ringkasan, dan tagar sesuai gaya platform terpilih. | Pengguna Tim Digital |
| **UC-04** | **Sunting Caption** | Pengguna menyunting teks draf caption, memeriksa jumlah karakter, atau meminta AI membuat draf ulang (regenerasi). | Pengguna Tim Digital |
| **UC-05** | **Siap Pakai** | Pengguna menetapkan teks caption yang sudah valid menjadi status siap pakai dan menyalin teks ke papan klip. | Pengguna Tim Digital |
| **UC-06** | **Template Gambar** | Pengguna mengunggah foto, memilih rasio kanvas (1:1, 16:9, 9:16, 4:5), mengatur slider zoom/posisi, dan mengunduh gambar PNG. | Pengguna Tim Digital |
| **UC-07** | **Jadwal** | Pengguna menentukan waktu posting per platform dan melihat agenda pada tampilan kalender bulanan. | Pengguna Tim Digital |
| **UC-08** | **Tandai Terbit** | Pengguna menandai status caption terjadwal/siap menjadi "terbit" setelah penayangan dilakukan. | Pengguna Tim Digital |

---

## 4. Hal yang TIDAK Dipenuhi Aplikasi dan Alasannya

Berdasarkan kesepakatan batasan proyek dan analisis kelayakan skripsi:

1. **Integrasi Langsung Otomatis dengan Database CMS Web / RSS Feed**  
   - *Kondisi Wawancara:* Pada `[H2]`, staf menginginkan integrasi satu pintu naskah web otomatis mendorong draf caption.  
   - *Alasan Tidak Dipenuhi:* CMS web memiliki arsitektur terpisah dan hak akses terbatas (`[E4]`). Pembuatan webhook/API CMS menambah kompleksitas dan risiko keamanan di luar cakupan skripsi pemula. Solusi yang diambil adalah penempelan (*copy-paste*) naskah secara manual yang tetap cepat dan andal.
2. **Pencarian / Pengambilan Stok Foto Otomatis**  
   - *Kondisi Wawancara:* Hambatan stok foto disebutkan pada `[B3]`.  
   - *Alasan Tidak Dipenuhi:* Aplikasi tidak mengintegrasikan sistem pencarian repositori foto internal atau layanan pihak ketiga berbayar. Pengguna tetap mengunggah file foto secara mandiri ke kanvas peramban.
3. **Otomatisasi Konten Video**  
   - *Kondisi Wawancara:* Konten media sosial mencakup platform video seperti TikTok dan YouTube (`[F1]`, `[F3]`).  
   - *Alasan Tidak Dipenuhi:* Pemrosesan rendering video membutuhkan spesifikasi komputasi tinggi dan arsitektur server kompleks. Generator gambar dibatasi murni pada grafis diam (*still image*) berbasis HTML5 Canvas.
4. **Unggah Otomatis Langsung ke Seluruh Platform (TikTok & YouTube)**  
   - *Kondisi Wawancara:* Diungkapkan pada `[F2]` bahwa penjadwalan platform non-Meta masih manual.  
   - *Alasan Tidak Dipenuhi:* API TikTok dan YouTube memiliki prosedur audit perizinan, verifikasi badan hukum, serta kuota yang sangat ketat untuk aplikasi skripsi independen. Untuk platform ini, pengguna menggunakan metode salin teks manual lalu menekan tombol "Tandai Terbit".
5. **Hierarki Peran Pengguna Bertingkat (Role & Permission) dan Alur Persetujuan (Approval Workflow)**  
   - *Kondisi Wawancara:* Wawancara `[E4]` menyebut pemisahan peran di CMS Web (Author & Editor).  
   - *Alasan Tidak Dipenuhi:* Di tim media sosial Radar Bojonegoro, manajer digital juga merangkap editor naskah. Penambahan alur persetujuan bertingkat justru menciptakan *bottleneck* baru yang berlawanan dengan target kecepatan publikasi berita (`[B1]`, `[H1]`).
6. **Fitur Registrasi Mandiri dan Pemulihan Kata Sandi (Forgot Password)**  
   - *Alasan Tidak Dipenuhi:* Sistem bersifat internal tertutup hanya untuk 2 pengguna terverifikasi, sehingga akun disediakan langsung melalui seeder database demi kesederhanaan sistem.

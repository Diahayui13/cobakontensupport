# Dokumen Desain Sistem (kontensupport)

Dokumen ini memuat perancangan teknis sistem *kontensupport* untuk tim digital Radar Bojonegoro berdasarkan **AGENTS.md Bagian 6, 7, dan 8**.

---

## 1. Entity Relationship Diagram (ERD)

Diagram ERD mencakup seluruh 10 tabel yang didefinisikan pada AGENTS.md Bagian 8. Tidak ada tabel tambahan di luar dokumen ketentuan.

```mermaid
erDiagram
    users {
        bigint id PK
        string name
        string email
        string password
        datetime created_at
        datetime updated_at
    }

    platforms {
        bigint id PK
        string name
        string slug
        int char_limit
        string image_ratios
        text style_rules
        datetime created_at
        datetime updated_at
    }

    content_types {
        bigint id PK
        string name
        text style_rules
        text example
        datetime created_at
        datetime updated_at
    }

    articles {
        bigint id PK
        bigint user_id FK
        string title
        text body
        text notes_for_ai
        bigint content_type_id FK
        datetime created_at
        datetime updated_at
    }

    captions {
        bigint id PK
        bigint article_id FK
        bigint platform_id FK
        int attempt_no
        text ai_text
        text final_text
        text hashtags
        text summary
        string status
        datetime ready_at
        datetime created_at
        datetime updated_at
    }

    ai_requests {
        bigint id PK
        bigint article_id FK
        datetime started_at
        int duration_ms
        string status
        text error_message
        datetime created_at
        datetime updated_at
    }

    activity_logs {
        bigint id PK
        bigint user_id FK
        string action
        string object_type
        bigint object_id
        datetime created_at
    }

    schedules {
        bigint id PK
        bigint caption_id FK "UNIQUE"
        datetime scheduled_at
        text notes
        datetime created_at
        datetime updated_at
    }

    social_accounts {
        bigint id PK
        string platform
        string account_name
        text credentials "terenkripsi"
        datetime expires_at
        datetime created_at
        datetime updated_at
    }

    post_attempts {
        bigint id PK
        bigint caption_id FK
        datetime attempted_at
        string status
        text message
        datetime created_at
        datetime updated_at
    }

    users ||--o{ articles : "membuat"
    users ||--o{ activity_logs : "melakukan"
    content_types ||--o{ articles : "menentukan tipe"
    articles ||--o{ captions : "memiliki"
    articles ||--o{ ai_requests : "memicu"
    platforms ||--o{ captions : "target"
    captions ||--o| schedules : "dijadwalkan (1:1)"
    captions ||--o{ post_attempts : "memiliki riwayat unggah"
```

---

## 2. Diagram Status Caption

Status caption diatur secara ketat dengan 5 nilai yang diperbolehkan: `draf`, `siap`, `terjadwal`, `terbit`, dan `gagal` (status `gagal` aktif pada Iterasi 5).

```mermaid
stateDiagram-v2
    [*] --> draf : Hasil Generate AI / Regenerasi Baru (attempt_no bertambah)

    draf --> siap : Tekan Tombol "Siap Pakai" (simpan final_text & salin ke clipboard)
    
    siap --> draf : Pengguna Menyunting Teks (final_text diubah)
    
    siap --> terjadwal : Atur Waktu di Jadwal/Kalender (buat entri schedules)
    
    terjadwal --> draf : Pengguna Menyunting Teks (otomatis batalkan jadwal)
    
    siap --> terbit : Tekan Tombol "Tandai Terbit" (manual langsung)
    
    terjadwal --> terbit : Waktu tiba & tekan "Tandai Terbit" manual / Otomatis Sistem (Iterasi 5)
    
    terjadwal --> gagal : Unggah otomatis gagal setelah batas percobaan habis (Iterasi 5)
    
    gagal --> terjadwal : Coba Lagi / Jadwalkan Ulang (Iterasi 5)
    
    gagal --> draf : Kembalikan ke draf untuk perbaikan teks
    
    terbit --> [*] : Konten Selesai Terdistribusi (Arsip Final)
```

---

## 3. Tabel Aturan Perpindahan Status Caption

Semua aturan transisi ini **ditegakkan di tingkat SERVER** (Controller & Model), bukan hanya validasi visual di tombol peramban.

| Status Awal | Status Tujuan | Aksi / Pemicu | Validasi & Aturan Server | Efek Samping Sistem & Log |
| :--- | :--- | :--- | :--- | :--- |
| *(Baru)* | `draf` | Klik "Buat Caption" / "Buat Ulang" | Hasil JSON Gemini valid, `attempt_no` bertambah untuk platform terkait. | Teks AI disimpan permanen di `ai_text` (tidak boleh diubah). Mencatat log `captions_generated` atau `caption_regenerated`. |
| `draf` | `siap` | Klik "Siap Pakai" | Teks tersimpan tidak kosong dan memenuhi batas karakter platform. | Menyimpan isi ke `final_text`, mengisi `ready_at = now()`, mencatat log `caption_ready`. Teks disalin ke clipboard peramban. |
| `siap` | `draf` | Pengguna menyunting teks `final_text` | Request perubahan teks masuk ke server saat status saat ini adalah `siap`. | Status diturunkan ke `draf`, kolom `ready_at` di-null-kan kembali, mencatat log `caption_edited`. |
| `siap` | `terjadwal` | Mengatur tanggal/jam di Jadwal | Validasi server: `status` HARUS `siap`. Waktu `scheduled_at` harus di masa depan. | Membuat atau memperbarui baris unik di tabel `schedules`. Status caption menjadi `terjadwal`. Mencatat log `schedule_set`. |
| `terjadwal` | `draf` | Pengguna menyunting teks `final_text` | Request perubahan teks masuk saat status adalah `terjadwal`. | **Aturan Tegas Server:** Jadwal otomatis dibatalkan (baris di `schedules` dihapus), status menjadi `draf`, mencatat log `schedule_cancelled` dan `caption_edited`. |
| `siap` | `terbit` | Klik "Tandai Terbit" | Teks siap dipakai sudah diunggah secara manual oleh staf. | Status menjadi `terbit`, mencatat log `marked_published`. Konten terkunci permanen. |
| `terjadwal` | `terbit` | Klik "Tandai Terbit" manual ATAU eksekusi otomatis berhasil (Iterasi 5) | Jadwal tiba, sistem berhasil posting API atau dikonfirmasi staf secara manual. | Baris jadwal diselesaikan, status menjadi `terbit`, mencatat log `marked_published` atau `post_success`. |
| `terjadwal` | `gagal` | Gagal unggah otomatis via API (Iterasi 5) | Percobaan pemanggilan API melebihi batas percobaan (`post_attempts`). | Status menjadi `gagal`, mencatat log `post_failed`. Menampilkan pesan galat di antarmuka. |
| `gagal` | `terjadwal` | Pengguna klik "Coba Lagi" (Iterasi 5) | Kredensial akun sosial aktif dan waktu dijadwalkan ulang. | Reset percobaan, status kembali `terjadwal`. Mencatat log `schedule_set`. |
| `gagal` | `draf` | Pengguna memilih revisi | Mengembalikan caption ke tahap penyuntingan draf awal. | Status menjadi `draf`, baris jadwal dibatalkan. |

> **Prinsip Utama:** Teks hasil AI (`ai_text`) **TIDAK PERNAH** dapat diposting atau dijadwalkan secara langsung sebelum pengguna menekan tombol "Siap Pakai". Tidak ada status menunggu persetujuan (*no approval workflow*).

---

## 4. Arsitektur Sederhana Sistem

Arsitektur aplikasi dirancang modular dan sederhana sesuai arahan skripsi pemula tanpa menambah lapisan arsitektur rumit (tanpa Redis, tanpa Message Queue terpisah, dan tanpa microservices).

```mermaid
graph TD
    subgraph Peramban_Klien ["1. Peramban Klien (Frontend)"]
        UI["Antarmuka Blade + Tailwind CSS"]
        ALPINE["Interaktivitas Alpine.js (Tab, Counter, Salin Teks)"]
        CANVAS["HTML5 Canvas API (Olah Foto Lokal, Rasio 1:1, 16:9, 9:16, 4:5, Unduh PNG)"]
    end

    subgraph Server_Laravel ["2. Server Lokal / Hosting (Backend Laravel 11)"]
        ROUTER["Web Routes & Auth Breeze"]
        CONTROLLER["Controllers (Artikel, Caption, Jadwal)"]
        GEMINI_SVC["GeminiService (HTTP Client Laravel)"]
        POSTING_SVC["PostingService (Iterasi 5 - Facebook, IG, X)"]
        SCHEDULER["Laravel Scheduler (Cron tiap menit)"]
    end

    subgraph Basis_Data ["3. Basis Data"]
        MYSQL[("MySQL Database - 10 Tabel")]
    end

    subgraph Layanan_Eksternal ["4. Layanan Eksternal & Platform API"]
        GEMINI_API["Google Gemini API (Generasi Teks & Rekomendasi Tagar)"]
        META_API["Meta Graph API (Iterasi 5: Facebook & Instagram)"]
        X_API["X API v2 (Iterasi 5: Post Tweet)"]
        MANUAL_POST["Manual Web/App (TikTok & YouTube: Salin Teks + Unggah Manual)"]
    end

    %% Alur Interaksi
    UI <-->|HTTP Request / Blade Views| ROUTER
    ALPINE <--> UI
    CANVAS -->|Diproses Lokal di Browser Pengguna| UI

    ROUTER --> CONTROLLER
    CONTROLLER <-->|Eloquent ORM| MYSQL
    
    CONTROLLER -->|Rakit Prompt & Panggil AI| GEMINI_SVC
    GEMINI_SVC -->|HTTPS POST JSON| GEMINI_API
    GEMINI_API -->|Respon JSON Tervalidasi| GEMINI_SVC

    SCHEDULER -->|Periksa Jadwal Siap| POSTING_SVC
    POSTING_SVC -->|Posting Otomatis Berjadwal| META_API
    POSTING_SVC -->|Posting Otomatis Berjadwal| X_API
    
    UI -.->|Salin Teks Final ke Clipboard| MANUAL_POST

    classDef client fill:#e0f2fe,stroke:#0284c7,stroke-width:2px;
    classDef server fill:#fef3c7,stroke:#d97706,stroke-width:2px;
    classDef db fill:#dcfce7,stroke:#16a34a,stroke-width:2px;
    classDef ext fill:#f3e8ff,stroke:#9333ea,stroke-width:2px;

    class UI,ALPINE,CANVAS client;
    class ROUTER,CONTROLLER,GEMINI_SVC,POSTING_SVC,SCHEDULER server;
    class MYSQL db;
    class GEMINI_API,META_API,X_API,MANUAL_POST ext;
```

---

## 5. Analisis Keselarasan Aturan & Catatan Konfirmasi

Berdasarkan penelaahan teliti terhadap AGENTS.md Bagian 6, 7, dan 8:

1. **Pencatatan Waktu Terbit:**
   - Di tabel `captions` terdapat kolom `ready_at`, namun **tidak ada kolom `published_at`**.
   - *Penyelarasan:* Waktu terbit tidak disimpan dengan menambahkan kolom baru di tabel `captions`, melainkan dicatat secara akurat di tabel `activity_logs` dengan aksi `marked_published` (manual) atau `post_success` (otomatis Iterasi 5). Status pada tabel `captions` diubah menjadi `terbit`.
2. **Kolom Platform pada `social_accounts`:**
   - Pada tabel `social_accounts`, dokumen mencantumkan kolom `platform` (string), bukan `platform_id`.
   - *Penyelarasan:* Nilai ini menyimpan string slug platform (misal: `'facebook'`, `'instagram'`, `'x'`) yang selaras dengan kolom `slug` pada tabel `platforms`.
3. **Mekanisme Pembatalan Jadwal Saat Teks Disunting:**
   - Aturan Bagian 7 menyatakan: *"Mengubah teks caption yang berstatus siap atau terjadwal mengembalikannya ke draf dan membatalkan jadwalnya."*
   - *Penyelarasan Server:* Saat sebuah caption berstatus `terjadwal` disunting teksnya, server akan menghapus entri jadwal terkait di tabel `schedules`, mengembalikan status caption menjadi `draf`, serta mencatat dua aktivitas di `activity_logs`: `schedule_cancelled` dan `caption_edited`.

# PROGRESS.md

## Status sekarang

- Iterasi aktif: Migrasi Lingkungan AI Studio & Modul Auto Caption (Iterasi 1) Berjalan
- Tugas terakhir selesai: Perbaikan galat inisialisasi Inertia `Cannot read properties of null (reading 'component')` dengan menyediakan tag `<script data-page="app" type="application/json">` di `index.html` dan `server.ts`, serta fungsi pembaca data awal tangguh di `resources/js/app.js`.
- Tugas berikutnya: Menutup Iterasi 1 secara resmi ke Git dengan tag `iterasi-1-selesai` dan sinkronisasi ke branch `iterasi-2` untuk modul Canvas Desain.
- Masalah terbuka / Catatan Berjalan:
  - **PENGINGAT KEAMANAN:** Rute `/health` di `server.ts` harus dihapus atau dilindungi login sebelum rilis produksi final.
  - **Transisi Kolom Jenis Konten (Tugas 1.C):** Kolom lama `articles.content_type` (string) tetap dipertahankan dan masih berisi nilai bawaan "hard_news" untuk artikel baru, serta hanya akan dibersihkan di tugas terpisah setelah seluruh modul terbukti berjalan stabil. Kode baru sepenuhnya membaca dan menulis kolom `articles.content_type_id`.
  - **Status Awal Tiga Jenis Konten (Tugas 1.C):** Tiga jenis konten awal (Berita Lugas, Breaking News, Feature) berstatus sebagai data contoh awal dan akan divalidasi oleh editor Radar Bojonegoro. Penanda contoh dicatat di dokumentasi dan teks bantuan antarmuka, bukan pada kolom database `style_rules` yang dimuat ke prompt AI.
  - Bukti deploy kerangka di hosting asli (tercatat di docs/deploy-kerangka.md).
  - Nama hosting target yang pasti (menunggu koordinasi pemilik proyek).
  - Konfirmasi dosen: apakah unggah otomatis (Facebook dan Instagram) masuk cakupan penuh Iterasi 5.
  - Kontak dan koordinasi lanjutan dengan tim redaksi Radar Bojonegoro.
  - Verifikasi berkala batas karakter dan rasio tiap platform sebelum rilis.

## Isian yang sudah diverifikasi

- Versi PHP lokal: PHP 8.3 (Laragon PHP 8.3.26)
- Model Gemini yang dipakai dan kuota (tanggal cek, sumber): `gemini-3.5-flash-lite` (diverifikasi per 14 Oktober 2026 via Google AI Studio API `generateContent`, model lama `gemini-1.5-flash` sudah kedaluwarsa/404).
- Ketentuan data layanan AI: Pada kuota gratis, prompt dan respons dapat dipakai Google untuk melatih model dan dapat ditinjau manusia; layanan berbayar tidak melatih model (ringkasan Tugas 0.10, tanggal baca 13 Oktober 2026, BELUM diverifikasi manual; dokumen lengkap ada di cabang upgrade-laravel). Penyedia = Gemini API langsung (dicatat per 19 Oktober 2026).

## Belum diverifikasi manual

- Hosting yang dipilih dan verifikasi fiturnya (nama hosting target belum disebutkan):
  - Cron / Scheduler: hanya teruji di lokal (Laragon), belum di hosting asli.
  - Panggilan keluar API (HTTP): hanya teruji di lokal (Laragon), belum di hosting asli.
  - HTTPS: hanya teruji di lokal (Laragon), belum di hosting asli.
- Batas karakter dan rasio tiap platform (sumber, tanggal cek):
  - Instagram: 2.200 (TODO-VERIFY) karakter, rasio 1:1, 4:5, 9:16 (TODO-VERIFY) — [Meta Graph API Docs](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/content-publishing) (Oktober 2026).
  - Facebook: 63.206 (TODO-VERIFY) karakter, rasio 1:1, 16:9, 4:5 (TODO-VERIFY) — [Meta Graph API Docs](https://developers.facebook.com/docs/pages-api/posts) (Oktober 2026).
  - X: 280 (TODO-VERIFY)(a) karakter, rasio 16:9, 1:1 (TODO-VERIFY) — tidak ada sumber spesifik; verifikasi lewat pusat bantuan platform atau penghitung karakter di kolom tulis platform (Oktober 2026). (a) Catatan: batas 280 karakter berlaku untuk akun biasa (non-Premium/tanpa langganan).
  - TikTok: 2.200 (TODO-VERIFY)(b) karakter, rasio 9:16 (TODO-VERIFY) — tidak ada sumber spesifik; verifikasi lewat pusat bantuan platform atau penghitung karakter di kolom tulis platform (Oktober 2026). (b) Catatan: batas TikTok perlu dicek ulang karena dapat bervariasi tergantung jenis postingan/kebijakan aplikasi.
  - YouTube: 5.000 (Deskripsi, TODO-VERIFY)(c), 100 (Judul, TODO-VERIFY) karakter, rasio 16:9, 9:16 (TODO-VERIFY) — [YouTube Data API v3 Docs](https://developers.google.com/youtube/v3) (Oktober 2026). (c) Catatan: batas deskripsi YouTube di API mungkin dalam byte (TODO-VERIFY).
  - Catatan sumber: Tautan Meta dan YouTube adalah dokumentasi API, bukan sumber batas karakter yang dilihat pengguna di antarmuka aplikasi.

## Hasil uji kelayakan API (Iterasi 0)

> **Catatan:** Hasil ini dari membaca dokumentasi, belum ada posting percobaan sungguhan ke akun mana pun, dan angka harga X belum diverifikasi dari portal developer.

| Platform | Bisa posting lewat API? | Izin atau review yang diperlukan | Biaya atau kuota | Keputusan (masuk Iterasi 5 / cadangan manual) |
| --- | --- | --- | --- | --- |
| Facebook | Ya (Bisa) | Page Access Token dengan izin `pages_manage_posts`, `pages_read_engagement`. Mode live butuh Meta App Review, mode dev bisa langsung oleh admin Page. | Gratis (standar Graph API rate limits) | **Masuk Iterasi 5** (otomatis via Meta Graph API) |
| Instagram | Ya (Bersyarat) | Akun Instagram Professional (Business/Creator) terhubung ke Facebook Page. Izin `instagram_basic`, `instagram_content_publish`. Butuh Meta App Review untuk mode live. | Gratis (kuota maks. 100 post / 24 jam) | **Masuk Iterasi 5 (Bersyarat)**: Gambar wajib memiliki URL publik di internet (diunggah sementara ke penyimpanan publik sebelum diposting, lalu dihapus). |
| X | Tidak (Terkendala Biaya) | OAuth 1.0a / OAuth 2.0 PKCE via X Developer Portal. | **Berbayar** ($0.015/tweet (TODO-VERIFY) atau Basic Plan $100/bulan (TODO-VERIFY)). Tidak ada free tier fungsional untuk media upload. | **Cadangan Manual** (Salin teks, unduh gambar, posting manual di x.com, lalu tekan tombol "Tandai Terbit"). Sesuai aturan skripsi: tidak memaksakan API berbayar. |

## Keputusan (tanggal, keputusan, alasan)

- 2026-10-13: Upgrade framework backend ke Laravel 13 (v13.35.0) dengan PHPUnit 11, Collision 8.9, dan Tinker 3.0 setelah persetujuan pengguna.
- 2026-10-13: Migrasi arsitektur frontend dan database ke Inertia.js (Vue 3), PrimeVue v4 (preset Aura), Tailwind CSS, PostgreSQL, Fabric.js v6+, serta ContentGeneratorService berbasis Google AI Studio (Gemini Flash).
- 2026-10-11: Framework Laravel versi 11.57.0 saat ini terpasang sementara untuk pengembangan awal, tetapi versi final belum diputuskan menunggu pengecekan masa dukungan.
- 2026-10-11: Facebook dan Instagram DIRENCANAKAN untuk Iterasi 5, bersyarat dan belum dikonfirmasi dosen; X memakai cadangan manual karena API berbayar (harga belum diverifikasi).

## Catatan per iterasi

### Iterasi 0

- Mulai / selesai: 2026-10-11 / 2026-10-13 (Selesai Penuh)
- Tugas selesai:
  - Tugas 0.1 Inisialisasi proyek Laravel 11 kosong, MySQL lokal, struktur docs/, dan gitignore.
  - Tugas 0.2 Dokumen analisis kebutuhan sistem (docs/analisis.md) berbasis wawancara Radar Bojonegoro.
  - Tugas 0.3 Dokumen desain sistem (docs/desain.md) mencakup ERD 10 tabel, diagram status caption, arsitektur sederhana, dan tabel aturan transisi status.
  - Tugas 0.4 Mockup statis antarmuka desktop di docs/mockup/ (login.html, konten.html, detail-konten.html 4 tab dengan 5 kartu platform: Instagram, X, Facebook, TikTok, dan YouTube, kalender.html).
  - Tugas 0.5 Halaman diagnostik `/health`, scheduler heartbeat tiap menit (`routes/console.php`), panduan deploy untuk pemula (`docs/deploy-kerangka.md`), dan pengujian unit/feature (`tests/Feature/HealthCheckTest.php`).
  - Tugas 0.6 Skrip spike mandiri di folder `spike/` (diisolasi di `.gitignore`) untuk uji kelayakan posting Facebook, Instagram, dan X, serta pelaporan kelayakan dari dokumentasi di `PROGRESS.md`.
- Masalah dan solusi: Galat `Table 'sessions' doesn't exist` di peramban saat mengakses `/health` sebelum migrasi database dijalankan. Diatasi dengan mengecualikan middleware sesi (`withoutMiddleware('web')`) pada rute `/health` dan mengubah `SESSION_DRIVER=file` di `.env`.
- Masukan editor (tanggal, siapa, isi): -
- Hasil uji (lolos / gagal, rujuk docs/kasus-uji.md): ExampleTest, HealthCheckTest, dan ContentGeneratorServiceTest lolos di Laravel 13 (4 passed, 13 assertions). Skrip spike teruji sintaks dan alur tanggapan API. Seluruh tampilan UI mockup terverifikasi di Inertia.js.
- Tag Git: `iterasi-0-selesai`.
- Bukti: folder docs/ (docs/README.md, docs/analisis.md, docs/desain.md, docs/mockup/, docs/deploy-kerangka.md), folder terisolasi spike/, dan halaman-halaman Inertia di resources/js/Pages/.

### Iterasi 1: Modul Auto Caption

- Mulai / selesai: 2026-10-13 / 2026-10-19 (Selesai Penuh)
- Tugas selesai:
  - Tugas 1.1 Penyesuaian arsitektur SDLC per modul di AGENTS.md, pembuatan migrasi database 5 tabel pokok (`platforms`, `articles`, `captions`, `ai_requests`, `activity_logs`), model Eloquent, seeder 5 platform (`PlatformSeeder`) & 2 pengguna redaksi (`UserSeeder`), serta pengujian otomatis relasi database di `tests/Feature/DatabaseSchemaTest.php`.
  - Tugas 1.2 Integrasi data riil database dan generator Gemini AI untuk seluruh alur Modul Auto Caption (`ArticleController`, `ArticleSeeder`, form tambah artikel, kartu caption 5 platform, tombol Buat Ulang dengan animasi pemrosesan tanpa dialog alert, penyimpanan draf, dan penguncian status Siap Pakai yang menyalin teks ke papan klip).
  - Tugas 1.3 Perbaikan tombol "Buat Ulang Caption Semua Platform" pada artikel tersimpan dengan menambahkan rute dan handler `POST /articles/{articleId}/regenerate` (`regenerateAllCaptions`) agar memperbarui artikel yang ada dan membuat draf caption baru (`attempt_no` bertambah) tanpa menduplikasi data artikel.
  - Tugas 1.4 Pembaruan model Gemini API ke `gemini-3.5-flash-lite` di `.env` & `.env.example` setelah `gemini-1.5-flash` kedaluwarsa/404, serta perbaikan penerusan notifikasi flash `success` dan `error` pada middleware `HandleInertiaRequests`.
  - Tugas 1.5 Pembersihan data sampah pengujian otomatis di database lokal, serta isolasi database testing SQLite memori.
  - Tugas 1.6 Penyesuaian antarmuka UI/UX `Detail.vue` dengan mockup 4 tab (Naskah, Caption AI, Visual, Jadwal).
  - Tugas 1.7 Implementasi autentikasi login internal riil (`AuthController.php`), penutupan rute redaksi dengan middleware `auth`, pembatasan rate limiter (5 percobaan/menit), form login `Login.vue`, tombol keluar di sidebar `AppLayout.vue`, shared props `auth.user` di `HandleInertiaRequests.php`, dan pengujian fitur autentikasi (`AuthTest.php` & `AuthControllerTest.php`).
  - Tugas 1.8 (Tugas 1.C Tim) Pengelolaan jenis konten dinamis: tabel `content_types`, seeder `ContentTypeSeeder` (Berita Lugas, Breaking News, Feature), halaman CRUD jenis konten (`ContentTypeController.php`, `JenisKonten/Index.vue`), serta penyisipan otomatis `style_rules` jenis konten ke prompt Gemini AI generator (`ContentGeneratorService.php`).
- Masalah dan solusi: Pengguna sebelumnya dapat mengakses rute konten tanpa login karena autentikasi masih berupa navigasi tiruan; diatasi dengan mengimplementasikan sistem sesi riil Laravel (`Auth::attempt`) dan melindungi seluruh rute konten dengan middleware `auth`.
- Masukan editor (tanggal, siapa, isi): -
- Hasil uji: Seluruh 33 kasus uji dari 8 berkas tes lolos (`php artisan test`).
- Tag Git: `iterasi-1-selesai`.
- Bukti: `app/Http/Controllers/AuthController.php`, `app/Http/Controllers/ContentTypeController.php`, `app/Models/ContentType.php`, `database/migrations/2026_10_16_000001_create_content_types_and_add_to_articles_table.php`, `database/seeders/ContentTypeSeeder.php`, `resources/js/Pages/JenisKonten/Index.vue`, `resources/js/Pages/Konten/Detail.vue`, `app/Services/ContentGeneratorService.php`, `tests/Feature/ContentTypeTest.php`, dan `PROGRESS.md`.

### Iterasi 2: Modul Canvas Desain (Akan Dimulai)

- Mulai / selesai: - / belum berjalan
- Target cakupan:
  1. Integrasi Fabric.js v6 secara penuh pada `Detail.vue` (Tab 3: Template Visual Gambar).
  2. Implementasi rasio kanvas: 1:1 (1080x1080), 4:5 (1080x1350), 9:16 (1080x1920), dan 16:9 (1920x1080).
  3. Unggah foto liputan dari komputer pengguna, pengaturan skala (_zoom_) dan pergeseran koordinat foto (X dan Y).
  4. Penyematan otomatis identitas visual Radar Bojonegoro (logo RB merah, tanggal liputan, label kategori, dan judul berita).
  5. Fitur ekspor dan unduh berkas gambar PNG lokal dari sisi peramban.
  6. Pencatatan log aktivitas `image_downloaded` di tabel `activity_logs`.

